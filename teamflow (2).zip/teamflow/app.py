# -*- coding: utf-8 -*-
"""
TeamFlow - plataforma de gestão de equipes (Flask + SQLite).

Quadros, tarefas, visões Kanban/Tabela/Calendário/Cronograma/Dashboard,
automações, integração com Power BI (CSV/JSON), Grafana (Infinity ou SimpleJSON),
Slack (webhook) e webhooks genéricos (Zapier, n8n, Make -> Jira, Google Drive...).

Execução:  python app.py   ->  http://127.0.0.1:5000
"""
import csv
import io
import json
import os
import secrets
import sqlite3
import threading
import time
import urllib.request
from collections import Counter
from datetime import date, datetime, timedelta, timezone

from flask import Flask, Response, abort, g, jsonify, request, send_from_directory

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("TEAMFLOW_DB", os.path.join(BASE_DIR, "teamflow.db"))

PRIORITIES = ["Baixa", "Média", "Alta", "Urgente"]
DEFAULT_STATUSES = ["A fazer", "Em andamento", "Em revisão", "Concluído"]
TRIGGERS = ["task_created", "status_changed", "priority_changed", "assignee_changed", "overdue"]
ACTIONS = ["set_status", "set_priority", "assign_to", "set_progress", "add_comment", "notify_slack"]
MEMBER_COLORS = ["#ff5a3c", "#2f6fed", "#22b573", "#a855f7", "#f5a524", "#0ea5e9", "#ec4899"]

app = Flask(__name__, static_folder=os.path.join(BASE_DIR, "static"), static_url_path="/static")
app.json.ensure_ascii = False
app.json.sort_keys = False
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0

SCHEMA = """
CREATE TABLE IF NOT EXISTS boards(
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, description TEXT DEFAULT '',
  color TEXT DEFAULT '#3b5bff', statuses TEXT NOT NULL, created_at TEXT);
CREATE TABLE IF NOT EXISTS members(
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT DEFAULT '',
  role TEXT DEFAULT '', color TEXT DEFAULT '#2f6fed');
CREATE TABLE IF NOT EXISTS tasks(
  id INTEGER PRIMARY KEY AUTOINCREMENT, board_id INTEGER NOT NULL, title TEXT NOT NULL,
  description TEXT DEFAULT '', status TEXT NOT NULL, priority TEXT DEFAULT 'Média',
  assignee_id INTEGER, start_date TEXT, due_date TEXT, progress INTEGER DEFAULT 0,
  estimate_h REAL DEFAULT 0, tags TEXT DEFAULT '', link TEXT DEFAULT '', position REAL DEFAULT 0,
  created_at TEXT, updated_at TEXT, completed_at TEXT);
CREATE TABLE IF NOT EXISTS comments(
  id INTEGER PRIMARY KEY AUTOINCREMENT, task_id INTEGER NOT NULL, author TEXT DEFAULT 'Você',
  text TEXT NOT NULL, created_at TEXT);
CREATE TABLE IF NOT EXISTS automations(
  id INTEGER PRIMARY KEY AUTOINCREMENT, board_id INTEGER NOT NULL, name TEXT DEFAULT '',
  trigger_type TEXT NOT NULL, trigger_value TEXT DEFAULT '', action_type TEXT NOT NULL,
  action_value TEXT DEFAULT '', enabled INTEGER DEFAULT 1, runs INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS automation_runs(
  automation_id INTEGER NOT NULL, task_id INTEGER NOT NULL, PRIMARY KEY(automation_id, task_id));
CREATE TABLE IF NOT EXISTS activity(
  id INTEGER PRIMARY KEY AUTOINCREMENT, board_id INTEGER, task_id INTEGER, text TEXT NOT NULL, created_at TEXT);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
"""


# ----------------------------------------------------------------------------
# Infra
# ----------------------------------------------------------------------------
class ApiError(Exception):
    def __init__(self, msg, code=400):
        super().__init__(msg)
        self.msg = msg
        self.code = code


@app.errorhandler(ApiError)
def _api_error(e):
    return jsonify({"erro": e.msg}), e.code


@app.errorhandler(401)
def _unauthorized(e):
    return jsonify({"erro": "Token inválido ou ausente. Copie o token em Integrações."}), 401


@app.errorhandler(404)
def _not_found(e):
    if request.path.startswith("/api/"):
        return jsonify({"erro": "Recurso não encontrado"}), 404
    return e


def now():
    return datetime.now().isoformat(timespec="seconds")


def today():
    return date.today().isoformat()


def connect():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def get_db():
    if "db" not in g:
        g.db = connect()
    return g.db


@app.teardown_appcontext
def _close_db(_exc=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def rows(conn, sql, args=()):
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def get_setting(conn, key, default=""):
    r = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return r["value"] if r else default


def set_setting(conn, key, value):
    conn.execute(
        "INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (key, value),
    )


def body():
    d = request.get_json(silent=True)
    if not isinstance(d, dict):
        raise ApiError("Corpo JSON inválido")
    return d


def log(conn, board_id, task_id, text):
    conn.execute(
        "INSERT INTO activity(board_id,task_id,text,created_at) VALUES(?,?,?,?)",
        (board_id, task_id, text, now()),
    )


def clean_date(v):
    if v in (None, ""):
        return None
    try:
        datetime.strptime(str(v)[:10], "%Y-%m-%d")
    except ValueError:
        raise ApiError("Data inválida: %s (use AAAA-MM-DD)" % v)
    return str(v)[:10]


def clean_url(v, campo="URL"):
    v = (v or "").strip()
    if v and not (v.startswith("http://") or v.startswith("https://")):
        raise ApiError("%s deve começar com http:// ou https://" % campo)
    return v[:1000]


def clean_statuses(lst):
    if not isinstance(lst, list):
        raise ApiError("Lista de colunas inválida")
    out = []
    for s in lst:
        s = str(s).strip()[:40]
        if s and s not in out:
            out.append(s)
    if len(out) < 2:
        raise ApiError("O quadro precisa de pelo menos 2 colunas (a última é a de concluído)")
    return out


# ----------------------------------------------------------------------------
# Domínio
# ----------------------------------------------------------------------------
def board_or_404(conn, bid):
    r = conn.execute("SELECT * FROM boards WHERE id=?", (bid,)).fetchone()
    if not r:
        raise ApiError("Quadro não encontrado", 404)
    d = dict(r)
    d["statuses"] = json.loads(d["statuses"])
    return d


def enrich(conn, tasks):
    boards = {}
    for b in rows(conn, "SELECT * FROM boards"):
        b["statuses"] = json.loads(b["statuses"])
        boards[b["id"]] = b
    members = {m["id"]: m for m in rows(conn, "SELECT * FROM members")}
    td = today()
    for t in tasks:
        b = boards.get(t["board_id"])
        t["board_name"] = b["name"] if b else ""
        t["done"] = 1 if (b and t["status"] == b["statuses"][-1]) else 0
        m = members.get(t["assignee_id"])
        t["assignee_name"] = m["name"] if m else ""
        t["overdue"] = 1 if (t["due_date"] and not t["done"] and t["due_date"] < td) else 0
    return tasks


TASK_SELECT = "SELECT tasks.*, (SELECT COUNT(*) FROM comments c WHERE c.task_id=tasks.id) AS comment_count FROM tasks"


def load_tasks(conn, board_id=None):
    if board_id:
        data = rows(conn, TASK_SELECT + " WHERE board_id=? ORDER BY position, id", (board_id,))
    else:
        data = rows(conn, TASK_SELECT + " ORDER BY board_id, position, id")
    return enrich(conn, data)


def get_task(conn, tid):
    data = rows(conn, TASK_SELECT + " WHERE id=?", (tid,))
    if not data:
        raise ApiError("Tarefa não encontrada", 404)
    return enrich(conn, data)[0]


def norm_task(conn, board, data):
    out = {}
    if "title" in data:
        t = (data["title"] or "").strip()
        if not t:
            raise ApiError("O título não pode ficar vazio")
        out["title"] = t[:300]
    if "description" in data:
        out["description"] = (data["description"] or "")[:5000]
    if "status" in data:
        if data["status"] not in board["statuses"]:
            raise ApiError("Status inválido para este quadro")
        out["status"] = data["status"]
    if "priority" in data:
        if data["priority"] not in PRIORITIES:
            raise ApiError("Prioridade inválida")
        out["priority"] = data["priority"]
    if "assignee_id" in data:
        v = data["assignee_id"]
        if v in (None, ""):
            out["assignee_id"] = None
        else:
            try:
                v = int(v)
            except (TypeError, ValueError):
                raise ApiError("Responsável inválido")
            if not conn.execute("SELECT 1 FROM members WHERE id=?", (v,)).fetchone():
                raise ApiError("Responsável não encontrado")
            out["assignee_id"] = v
    for f in ("start_date", "due_date"):
        if f in data:
            out[f] = clean_date(data[f])
    if "progress" in data:
        try:
            out["progress"] = max(0, min(100, int(float(data["progress"] or 0))))
        except (TypeError, ValueError):
            raise ApiError("Progresso inválido")
    if "estimate_h" in data:
        try:
            out["estimate_h"] = max(0.0, float(data["estimate_h"] or 0))
        except (TypeError, ValueError):
            raise ApiError("Horas estimadas inválidas")
    if "tags" in data:
        parts = [p.strip()[:30] for p in str(data["tags"] or "").split(",") if p.strip()]
        out["tags"] = ",".join(parts[:12])
    if "link" in data:
        out["link"] = clean_url(data["link"], "O link")
    if "position" in data:
        try:
            out["position"] = float(data["position"])
        except (TypeError, ValueError):
            raise ApiError("Posição inválida")
    return out


def check_dates(start, due):
    if start and due and start > due:
        raise ApiError("A data de início não pode ser depois do prazo")


def create_task(conn, data, actor="Você"):
    board = board_or_404(conn, data.get("board_id"))
    if not (data.get("title") or "").strip():
        raise ApiError("Informe o título da tarefa")
    data = dict(data)
    data.setdefault("status", board["statuses"][0])
    f = norm_task(conn, board, data)
    check_dates(f.get("start_date"), f.get("due_date"))
    if "position" not in f:
        f["position"] = conn.execute(
            "SELECT COALESCE(MAX(position),0)+1 FROM tasks WHERE board_id=?", (board["id"],)
        ).fetchone()[0]
    ts = now()
    status = f["status"]
    cur = conn.execute(
        """INSERT INTO tasks(board_id,title,description,status,priority,assignee_id,start_date,due_date,
           progress,estimate_h,tags,link,position,created_at,updated_at,completed_at)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            board["id"], f["title"], f.get("description", ""), status, f.get("priority", "Média"),
            f.get("assignee_id"), f.get("start_date"), f.get("due_date"), f.get("progress", 0),
            f.get("estimate_h", 0), f.get("tags", ""), f.get("link", ""), f["position"], ts, ts,
            ts if status == board["statuses"][-1] else None,
        ),
    )
    tid = cur.lastrowid
    log(conn, board["id"], tid, '%s criou a tarefa "%s"' % (actor, f["title"]))
    run_automations(conn, None, get_task(conn, tid), "created")
    conn.commit()
    task = get_task(conn, tid)
    emit_webhook(conn, "tarefa_criada", task)
    return task


def update_task(conn, tid, data, actor="Você"):
    before = get_task(conn, tid)
    board = board_or_404(conn, before["board_id"])
    f = norm_task(conn, board, data)
    check_dates(f.get("start_date", before["start_date"]), f.get("due_date", before["due_date"]))
    if not f:
        return before
    ts = now()
    if "status" in f and f["status"] != before["status"]:
        f["completed_at"] = ts if f["status"] == board["statuses"][-1] else None
    f["updated_at"] = ts
    sets = ", ".join("%s=?" % k for k in f)
    conn.execute("UPDATE tasks SET %s WHERE id=?" % sets, list(f.values()) + [tid])
    title = f.get("title", before["title"])
    if "status" in f and f["status"] != before["status"]:
        log(conn, board["id"], tid, '%s moveu "%s" de %s para %s' % (actor, title, before["status"], f["status"]))
    if "assignee_id" in f and f["assignee_id"] != before["assignee_id"]:
        m = conn.execute("SELECT name FROM members WHERE id=?", (f["assignee_id"],)).fetchone()
        log(conn, board["id"], tid, '%s atribuiu "%s" a %s' % (actor, title, m["name"] if m else "ninguém"))
    if "priority" in f and f["priority"] != before["priority"]:
        log(conn, board["id"], tid, '%s mudou a prioridade de "%s" para %s' % (actor, title, f["priority"]))
    after = get_task(conn, tid)
    run_automations(conn, before, after, "updated")
    conn.commit()
    after = get_task(conn, tid)
    emit_webhook(conn, "tarefa_atualizada", after)
    return after


def delete_task(conn, tid):
    t = get_task(conn, tid)
    conn.execute("DELETE FROM comments WHERE task_id=?", (tid,))
    conn.execute("DELETE FROM automation_runs WHERE task_id=?", (tid,))
    conn.execute("DELETE FROM tasks WHERE id=?", (tid,))
    log(conn, t["board_id"], None, 'Tarefa "%s" foi excluída' % t["title"])
    conn.commit()
    emit_webhook(conn, "tarefa_excluida", t)


# ----------------------------------------------------------------------------
# Automações
# ----------------------------------------------------------------------------
def trigger_matches(a, before, after, event):
    tt, tv = a["trigger_type"], (a["trigger_value"] or "")
    if tt == "task_created":
        return event == "created"
    if event != "updated" or not before:
        return False
    if tt == "status_changed":
        return before["status"] != after["status"] and tv in ("", "*", after["status"])
    if tt == "priority_changed":
        return before["priority"] != after["priority"] and tv in ("", "*", after["priority"])
    if tt == "assignee_changed":
        return before["assignee_id"] != after["assignee_id"]
    return False


def fmt_msg(conn, text, task):
    t = get_task(conn, task["id"])
    return (
        (text or "")
        .replace("{titulo}", t["title"])
        .replace("{status}", t["status"])
        .replace("{responsavel}", t["assignee_name"] or "ninguém")
        .replace("{quadro}", t["board_name"])
        .replace("{prazo}", t["due_date"] or "sem prazo")
        .replace("{prioridade}", t["priority"])
    )


def apply_action(conn, a, task):
    """Executa uma ação direto no banco (não dispara outras automações: sem laços)."""
    tid, t, v = task["id"], a["action_type"], (a["action_value"] or "")
    board = board_or_404(conn, task["board_id"])
    ts = now()
    if t == "set_status" and v in board["statuses"]:
        done_at = ts if v == board["statuses"][-1] else None
        conn.execute("UPDATE tasks SET status=?, completed_at=?, updated_at=? WHERE id=?", (v, done_at, ts, tid))
    elif t == "set_priority" and v in PRIORITIES:
        conn.execute("UPDATE tasks SET priority=?, updated_at=? WHERE id=?", (v, ts, tid))
    elif t == "assign_to" and v.isdigit() and conn.execute("SELECT 1 FROM members WHERE id=?", (int(v),)).fetchone():
        conn.execute("UPDATE tasks SET assignee_id=?, updated_at=? WHERE id=?", (int(v), ts, tid))
    elif t == "set_progress" and v.lstrip("-").isdigit():
        conn.execute("UPDATE tasks SET progress=?, updated_at=? WHERE id=?", (max(0, min(100, int(v))), ts, tid))
    elif t == "add_comment" and v:
        conn.execute(
            "INSERT INTO comments(task_id,author,text,created_at) VALUES(?,?,?,?)",
            (tid, "Automação", fmt_msg(conn, v, task)[:2000], ts),
        )
    elif t == "notify_slack":
        url = get_setting(conn, "slack_webhook")
        if url:
            post_json_async(url, {"text": fmt_msg(conn, v or "{responsavel} atualizou \"{titulo}\"", task)})
        else:
            log(conn, board["id"], tid, "Automação \"%s\": configure o webhook do Slack em Integrações" % a["name"])
    else:
        return
    conn.execute("UPDATE automations SET runs=runs+1 WHERE id=?", (a["id"],))
    log(conn, board["id"], tid, 'Automação "%s" executada em "%s"' % (a["name"] or "sem nome", task["title"]))


def run_automations(conn, before, after, event):
    for a in rows(conn, "SELECT * FROM automations WHERE board_id=? AND enabled=1", (after["board_id"],)):
        if trigger_matches(a, before, after, event):
            apply_action(conn, a, after)


def check_overdue():
    """Dispara automações com gatilho 'tarefa atrasada' (uma vez por tarefa)."""
    conn = connect()
    try:
        for a in rows(conn, "SELECT * FROM automations WHERE trigger_type='overdue' AND enabled=1"):
            for t in load_tasks(conn, a["board_id"]):
                if not t["overdue"]:
                    continue
                if conn.execute(
                    "SELECT 1 FROM automation_runs WHERE automation_id=? AND task_id=?", (a["id"], t["id"])
                ).fetchone():
                    continue
                conn.execute("INSERT INTO automation_runs VALUES(?,?)", (a["id"], t["id"]))
                apply_action(conn, a, t)
        conn.commit()
    finally:
        conn.close()


def start_scheduler():
    def loop():
        while True:
            try:
                check_overdue()
            except Exception as exc:  # noqa
                print("Erro ao verificar atrasos:", exc)
            time.sleep(300)

    threading.Thread(target=loop, daemon=True).start()


# ----------------------------------------------------------------------------
# Webhooks (Slack e genérico)
# ----------------------------------------------------------------------------
def post_json_sync(url, payload, timeout=6):
    req = urllib.request.Request(
        url, data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    urllib.request.urlopen(req, timeout=timeout).read()


def post_json_async(url, payload):
    def go():
        try:
            post_json_sync(url, payload)
        except Exception as exc:  # noqa
            print("Falha ao enviar webhook:", exc)

    threading.Thread(target=go, daemon=True).start()


def emit_webhook(conn, evento, task):
    url = get_setting(conn, "webhook_url")
    if url:
        post_json_async(url, {"evento": evento, "tarefa": task, "enviado_em": now()})


# ----------------------------------------------------------------------------
# Estatísticas (dashboard + Grafana)
# ----------------------------------------------------------------------------
def compute_stats(conn, board_id=None, days=14):
    tasks = load_tasks(conn, board_id)
    boards = rows(conn, "SELECT * FROM boards WHERE id=?", (board_id,)) if board_id else rows(conn, "SELECT * FROM boards ORDER BY id")
    status_order = []
    for b in boards:
        for s in json.loads(b["statuses"]):
            if s not in status_order:
                status_order.append(s)
    by_status = [{"name": s, "count": sum(1 for t in tasks if t["status"] == s)} for s in status_order]
    by_priority = [{"name": p, "count": sum(1 for t in tasks if t["priority"] == p)} for p in PRIORITIES]
    members = rows(conn, "SELECT * FROM members ORDER BY id")
    by_assignee = []
    for m in members + [{"id": None, "name": "Sem responsável", "color": "#8b93a7"}]:
        mine = [t for t in tasks if t["assignee_id"] == m["id"]]
        by_assignee.append({
            "name": m["name"], "color": m["color"], "total": len(mine),
            "done": sum(t["done"] for t in mine),
            "hours": round(sum(t["estimate_h"] or 0 for t in mine if not t["done"]), 1),
        })
    end = date.today()
    day_list = [(end - timedelta(days=i)).isoformat() for i in range(days - 1, -1, -1)]
    created = Counter((t["created_at"] or "")[:10] for t in tasks)
    completed = Counter((t["completed_at"] or "")[:10] for t in tasks if t["completed_at"])
    total, done = len(tasks), sum(t["done"] for t in tasks)
    first_status = {b["id"]: json.loads(b["statuses"])[0] for b in boards}
    in_progress = sum(1 for t in tasks if not t["done"] and t["status"] != first_status.get(t["board_id"]))
    limit = (end + timedelta(days=7)).isoformat()
    brief = lambda t: {k: t[k] for k in ("id", "title", "due_date", "assignee_name", "board_name", "priority")}
    return {
        "total": total, "done": done, "overdue": sum(t["overdue"] for t in tasks),
        "in_progress": in_progress, "completion_rate": round(100 * done / total) if total else 0,
        "by_status": by_status, "by_priority": by_priority, "by_assignee": by_assignee,
        "created_per_day": [{"date": d, "count": created.get(d, 0)} for d in day_list],
        "completed_per_day": [{"date": d, "count": completed.get(d, 0)} for d in day_list],
        "overdue_tasks": sorted([brief(t) for t in tasks if t["overdue"]], key=lambda x: x["due_date"]),
        "upcoming": sorted(
            [brief(t) for t in tasks if not t["done"] and t["due_date"] and today() <= t["due_date"] <= limit],
            key=lambda x: x["due_date"],
        ),
    }


# ----------------------------------------------------------------------------
# Rotas: front-end
# ----------------------------------------------------------------------------
@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


# ----------------------------------------------------------------------------
# Rotas: quadros
# ----------------------------------------------------------------------------
@app.get("/api/boards")
def boards_list():
    conn = get_db()
    out = []
    for b in rows(conn, "SELECT * FROM boards ORDER BY id"):
        b["statuses"] = json.loads(b["statuses"])
        ts = rows(conn, "SELECT status FROM tasks WHERE board_id=?", (b["id"],))
        b["task_count"] = len(ts)
        b["done_count"] = sum(1 for t in ts if t["status"] == b["statuses"][-1])
        out.append(b)
    return jsonify(out)


@app.post("/api/boards")
def boards_create():
    conn, d = get_db(), body()
    name = (d.get("name") or "").strip()
    if not name:
        raise ApiError("Dê um nome ao quadro")
    statuses = clean_statuses(d.get("statuses") or DEFAULT_STATUSES)
    cur = conn.execute(
        "INSERT INTO boards(name,description,color,statuses,created_at) VALUES(?,?,?,?,?)",
        (name[:80], (d.get("description") or "")[:300], d.get("color") or "#3b5bff", json.dumps(statuses, ensure_ascii=False), now()),
    )
    log(conn, cur.lastrowid, None, 'Quadro "%s" criado' % name)
    conn.commit()
    return jsonify(board_or_404(conn, cur.lastrowid)), 201


@app.put("/api/boards/<int:bid>")
def boards_update(bid):
    conn, d = get_db(), body()
    old = board_or_404(conn, bid)
    name = (d.get("name") or old["name"]).strip()
    if not name:
        raise ApiError("Dê um nome ao quadro")
    statuses = clean_statuses(d["statuses"]) if "statuses" in d else old["statuses"]
    for o, n in (d.get("renames") or {}).items():
        if o in old["statuses"] and n in statuses and o != n:
            conn.execute("UPDATE tasks SET status=? WHERE board_id=? AND status=?", (n, bid, o))
            conn.execute("UPDATE automations SET trigger_value=? WHERE board_id=? AND trigger_type='status_changed' AND trigger_value=?", (n, bid, o))
            conn.execute("UPDATE automations SET action_value=? WHERE board_id=? AND action_type='set_status' AND action_value=?", (n, bid, o))
    ph = ",".join("?" * len(statuses))
    conn.execute("UPDATE tasks SET status=? WHERE board_id=? AND status NOT IN (%s)" % ph, [statuses[0], bid] + statuses)
    conn.execute("UPDATE tasks SET completed_at=COALESCE(completed_at,?) WHERE board_id=? AND status=?", (now(), bid, statuses[-1]))
    conn.execute("UPDATE tasks SET completed_at=NULL WHERE board_id=? AND status!=?", (bid, statuses[-1]))
    conn.execute(
        "UPDATE boards SET name=?, description=?, color=?, statuses=? WHERE id=?",
        (name[:80], (d.get("description", old["description"]) or "")[:300], d.get("color") or old["color"], json.dumps(statuses, ensure_ascii=False), bid),
    )
    conn.commit()
    return jsonify(board_or_404(conn, bid))


@app.delete("/api/boards/<int:bid>")
def boards_delete(bid):
    conn = get_db()
    board = board_or_404(conn, bid)
    conn.execute("DELETE FROM comments WHERE task_id IN (SELECT id FROM tasks WHERE board_id=?)", (bid,))
    conn.execute("DELETE FROM automation_runs WHERE automation_id IN (SELECT id FROM automations WHERE board_id=?)", (bid,))
    for tbl in ("tasks", "automations", "activity"):
        conn.execute("DELETE FROM %s WHERE board_id=?" % tbl, (bid,))
    conn.execute("DELETE FROM boards WHERE id=?", (bid,))
    log(conn, None, None, 'Quadro "%s" foi excluído' % board["name"])
    conn.commit()
    return jsonify({"ok": True})


# ----------------------------------------------------------------------------
# Rotas: tarefas e comentários
# ----------------------------------------------------------------------------
@app.get("/api/tasks")
def tasks_list():
    bid = request.args.get("board_id", type=int)
    return jsonify(load_tasks(get_db(), bid))


@app.post("/api/tasks")
def tasks_create():
    return jsonify(create_task(get_db(), body())), 201


@app.put("/api/tasks/<int:tid>")
def tasks_update(tid):
    return jsonify(update_task(get_db(), tid, body()))


@app.delete("/api/tasks/<int:tid>")
def tasks_delete(tid):
    delete_task(get_db(), tid)
    return jsonify({"ok": True})


@app.get("/api/tasks/<int:tid>/comments")
def comments_list(tid):
    conn = get_db()
    get_task(conn, tid)
    return jsonify(rows(conn, "SELECT * FROM comments WHERE task_id=? ORDER BY id", (tid,)))


@app.post("/api/tasks/<int:tid>/comments")
def comments_create(tid):
    conn, d = get_db(), body()
    t = get_task(conn, tid)
    text = (d.get("text") or "").strip()
    if not text:
        raise ApiError("Escreva o comentário")
    cur = conn.execute(
        "INSERT INTO comments(task_id,author,text,created_at) VALUES(?,?,?,?)",
        (tid, (d.get("author") or "Você")[:60], text[:2000], now()),
    )
    log(conn, t["board_id"], tid, 'Novo comentário em "%s"' % t["title"])
    conn.commit()
    return jsonify(rows(conn, "SELECT * FROM comments WHERE id=?", (cur.lastrowid,))[0]), 201


# ----------------------------------------------------------------------------
# Rotas: equipe
# ----------------------------------------------------------------------------
@app.get("/api/members")
def members_list():
    return jsonify(rows(get_db(), "SELECT * FROM members ORDER BY name"))


@app.post("/api/members")
def members_create():
    conn, d = get_db(), body()
    name = (d.get("name") or "").strip()
    if not name:
        raise ApiError("Informe o nome")
    n = conn.execute("SELECT COUNT(*) FROM members").fetchone()[0]
    cur = conn.execute(
        "INSERT INTO members(name,email,role,color) VALUES(?,?,?,?)",
        (name[:80], (d.get("email") or "")[:120], (d.get("role") or "")[:80], d.get("color") or MEMBER_COLORS[n % len(MEMBER_COLORS)]),
    )
    conn.commit()
    return jsonify(rows(conn, "SELECT * FROM members WHERE id=?", (cur.lastrowid,))[0]), 201


@app.put("/api/members/<int:mid>")
def members_update(mid):
    conn, d = get_db(), body()
    old = conn.execute("SELECT * FROM members WHERE id=?", (mid,)).fetchone()
    if not old:
        raise ApiError("Pessoa não encontrada", 404)
    name = (d.get("name") or old["name"]).strip()
    conn.execute(
        "UPDATE members SET name=?, email=?, role=?, color=? WHERE id=?",
        (name[:80], (d.get("email", old["email"]) or "")[:120], (d.get("role", old["role"]) or "")[:80], d.get("color") or old["color"], mid),
    )
    conn.commit()
    return jsonify(rows(conn, "SELECT * FROM members WHERE id=?", (mid,))[0])


@app.delete("/api/members/<int:mid>")
def members_delete(mid):
    conn = get_db()
    conn.execute("UPDATE tasks SET assignee_id=NULL WHERE assignee_id=?", (mid,))
    conn.execute("UPDATE automations SET enabled=0 WHERE action_type='assign_to' AND action_value=?", (str(mid),))
    conn.execute("DELETE FROM members WHERE id=?", (mid,))
    conn.commit()
    return jsonify({"ok": True})


# ----------------------------------------------------------------------------
# Rotas: automações, atividade, dashboard
# ----------------------------------------------------------------------------
@app.get("/api/automations")
def automations_list():
    bid = request.args.get("board_id", type=int)
    if bid:
        return jsonify(rows(get_db(), "SELECT * FROM automations WHERE board_id=? ORDER BY id", (bid,)))
    return jsonify(rows(get_db(), "SELECT * FROM automations ORDER BY id"))


@app.post("/api/automations")
def automations_create():
    conn, d = get_db(), body()
    board = board_or_404(conn, d.get("board_id"))
    tt, at = d.get("trigger_type"), d.get("action_type")
    if tt not in TRIGGERS:
        raise ApiError("Gatilho inválido")
    if at not in ACTIONS:
        raise ApiError("Ação inválida")
    av = str(d.get("action_value") or "").strip()
    if at in ("set_status", "set_priority", "assign_to", "set_progress", "add_comment") and not av:
        raise ApiError("Informe o valor da ação")
    if at == "set_status" and av not in board["statuses"]:
        raise ApiError("A coluna escolhida não existe neste quadro")
    cur = conn.execute(
        "INSERT INTO automations(board_id,name,trigger_type,trigger_value,action_type,action_value,enabled) VALUES(?,?,?,?,?,?,1)",
        (board["id"], (d.get("name") or "")[:80], tt, str(d.get("trigger_value") or "")[:80], at, av[:500]),
    )
    conn.commit()
    return jsonify(rows(conn, "SELECT * FROM automations WHERE id=?", (cur.lastrowid,))[0]), 201


@app.put("/api/automations/<int:aid>")
def automations_update(aid):
    conn, d = get_db(), body()
    if not conn.execute("SELECT 1 FROM automations WHERE id=?", (aid,)).fetchone():
        raise ApiError("Automação não encontrada", 404)
    if "enabled" in d:
        conn.execute("UPDATE automations SET enabled=? WHERE id=?", (1 if d["enabled"] else 0, aid))
    if "name" in d:
        conn.execute("UPDATE automations SET name=? WHERE id=?", ((d["name"] or "")[:80], aid))
    conn.commit()
    return jsonify(rows(conn, "SELECT * FROM automations WHERE id=?", (aid,))[0])


@app.delete("/api/automations/<int:aid>")
def automations_delete(aid):
    conn = get_db()
    conn.execute("DELETE FROM automation_runs WHERE automation_id=?", (aid,))
    conn.execute("DELETE FROM automations WHERE id=?", (aid,))
    conn.commit()
    return jsonify({"ok": True})


@app.post("/api/automations/run-overdue")
def automations_run_overdue():
    check_overdue()
    return jsonify({"ok": True})


@app.get("/api/activity")
def activity_list():
    bid = request.args.get("board_id", type=int)
    limit = min(request.args.get("limit", 60, type=int), 300)
    if bid:
        return jsonify(rows(get_db(), "SELECT * FROM activity WHERE board_id=? ORDER BY id DESC LIMIT ?", (bid, limit)))
    return jsonify(rows(get_db(), "SELECT * FROM activity ORDER BY id DESC LIMIT ?", (limit,)))


@app.get("/api/dashboard")
def dashboard():
    return jsonify(compute_stats(get_db(), request.args.get("board_id", type=int)))


# ----------------------------------------------------------------------------
# Rotas: configurações e integrações
# ----------------------------------------------------------------------------
def settings_payload(conn):
    try:
        embeds = json.loads(get_setting(conn, "embeds", "[]"))
    except ValueError:
        embeds = []
    return {
        "api_token": get_setting(conn, "api_token"),
        "slack_webhook": get_setting(conn, "slack_webhook"),
        "webhook_url": get_setting(conn, "webhook_url"),
        "embeds": embeds,
    }


@app.get("/api/settings")
def settings_get():
    return jsonify(settings_payload(get_db()))


@app.put("/api/settings")
def settings_put():
    conn, d = get_db(), body()
    if "slack_webhook" in d:
        set_setting(conn, "slack_webhook", clean_url(d["slack_webhook"], "O webhook do Slack"))
    if "webhook_url" in d:
        set_setting(conn, "webhook_url", clean_url(d["webhook_url"], "A URL do webhook"))
    if "embeds" in d:
        if not isinstance(d["embeds"], list):
            raise ApiError("Lista de painéis inválida")
        clean = []
        for e in d["embeds"][:20]:
            url = clean_url(e.get("url"), "A URL do painel")
            if url:
                clean.append({
                    "name": (e.get("name") or "Painel")[:60],
                    "type": e.get("type") if e.get("type") in ("powerbi", "grafana", "outro") else "outro",
                    "url": url,
                })
        set_setting(conn, "embeds", json.dumps(clean, ensure_ascii=False))
    conn.commit()
    return jsonify(settings_payload(conn))


@app.post("/api/settings/regenerate-token")
def settings_regen():
    conn = get_db()
    set_setting(conn, "api_token", secrets.token_urlsafe(24))
    conn.commit()
    return jsonify(settings_payload(conn))


@app.post("/api/settings/test-slack")
def settings_test_slack():
    conn = get_db()
    url = get_setting(conn, "slack_webhook")
    if not url:
        raise ApiError("Salve primeiro o webhook do Slack")
    try:
        post_json_sync(url, {"text": "✅ TeamFlow conectado ao Slack."})
    except Exception as exc:  # noqa
        raise ApiError("O Slack não aceitou a mensagem: %s" % exc, 502)
    return jsonify({"ok": True})


def request_token():
    h = request.headers.get("Authorization", "")
    if h.lower().startswith("bearer "):
        h = h[7:]
    return request.args.get("token") or request.headers.get("X-API-Key") or h


def require_token(tok=None):
    tok = tok if tok is not None else request_token()
    real = get_setting(get_db(), "api_token")
    if not tok or not secrets.compare_digest(tok.encode("utf-8"), real.encode("utf-8")):
        abort(401)


@app.after_request
def cors(resp):
    if request.path.startswith("/api/bi") or request.path.startswith("/api/grafana"):
        resp.headers["Access-Control-Allow-Origin"] = "*"
        resp.headers["Access-Control-Allow-Headers"] = "Content-Type, X-API-Key, Authorization"
        resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    return resp


# --- Entrada: criar tarefa a partir de outra ferramenta (Jira, Zapier, n8n...) ---
@app.post("/api/integrations/tasks")
def integration_create_task():
    require_token()
    conn, d = get_db(), body()
    ref = d.get("board") or d.get("board_id")
    board = None
    if isinstance(ref, int) or (isinstance(ref, str) and ref.isdigit()):
        r = conn.execute("SELECT id FROM boards WHERE id=?", (int(ref),)).fetchone()
        board = r["id"] if r else None
    elif ref:
        r = conn.execute("SELECT id FROM boards WHERE lower(name)=lower(?)", (ref,)).fetchone()
        board = r["id"] if r else None
    else:
        r = conn.execute("SELECT id FROM boards ORDER BY id LIMIT 1").fetchone()
        board = r["id"] if r else None
    if not board:
        raise ApiError("Quadro não encontrado. Envie 'board' com o nome ou id do quadro.", 404)
    d = dict(d, board_id=board)
    d.pop("assignee_id", None)
    return jsonify(create_task(conn, d, actor="Integração")), 201


# --- Power BI / Excel: CSV e JSON ---
def _safe(v):
    if isinstance(v, str) and v[:1] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + v
    return v


def csv_response(cols, data, filename):
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow([c for c, _ in cols])
    for r in data:
        w.writerow([_safe(r.get(k, "")) if r.get(k) is not None else "" for _, k in cols])
    return Response(buf.getvalue(), mimetype="text/csv", headers={"Content-Disposition": 'inline; filename="%s"' % filename})


TASK_COLS = [
    ("id", "id"), ("quadro", "board_name"), ("titulo", "title"), ("descricao", "description"),
    ("status", "status"), ("concluida", "done"), ("prioridade", "priority"), ("responsavel", "assignee_name"),
    ("inicio", "start_date"), ("prazo", "due_date"), ("atrasada", "overdue"), ("progresso", "progress"),
    ("horas_estimadas", "estimate_h"), ("etiquetas", "tags"), ("link", "link"), ("comentarios", "comment_count"),
    ("criada_em", "created_at"), ("atualizada_em", "updated_at"), ("concluida_em", "completed_at"),
]
MEMBER_COLS = [("id", "id"), ("nome", "name"), ("email", "email"), ("cargo", "role"),
               ("tarefas", "total"), ("concluidas", "done"), ("horas_pendentes", "hours")]
BOARD_COLS = [("id", "id"), ("quadro", "name"), ("descricao", "description"), ("tarefas", "task_count"),
              ("concluidas", "done_count"), ("criado_em", "created_at")]


def _bi_data(kind):
    conn = get_db()
    if kind == "tasks":
        return TASK_COLS, load_tasks(conn, request.args.get("board_id", type=int))
    if kind == "members":
        tasks = load_tasks(conn)
        out = []
        for m in rows(conn, "SELECT * FROM members ORDER BY id"):
            mine = [t for t in tasks if t["assignee_id"] == m["id"]]
            m.update(total=len(mine), done=sum(t["done"] for t in mine),
                     hours=round(sum(t["estimate_h"] or 0 for t in mine if not t["done"]), 1))
            out.append(m)
        return MEMBER_COLS, out
    if kind == "boards":
        out = []
        for b in rows(conn, "SELECT * FROM boards ORDER BY id"):
            ts = rows(conn, "SELECT status FROM tasks WHERE board_id=?", (b["id"],))
            st = json.loads(b["statuses"])
            b.update(task_count=len(ts), done_count=sum(1 for t in ts if t["status"] == st[-1]))
            out.append(b)
        return BOARD_COLS, out
    abort(404)


@app.route("/api/bi/<kind>.csv", methods=["GET", "OPTIONS"])
def bi_csv(kind):
    require_token()
    cols, data = _bi_data(kind)
    return csv_response(cols, data, kind + ".csv")


@app.route("/api/bi/<kind>.json", methods=["GET", "OPTIONS"])
def bi_json(kind):
    require_token()
    cols, data = _bi_data(kind)
    return jsonify([{c: r.get(k) for c, k in cols} for r in data])


# --- Grafana: protocolo SimpleJSON (token no caminho da URL) ---
GRAFANA_METRICS = [
    "resumo", "tarefas_por_status", "tarefas_por_prioridade", "tarefas_por_responsavel",
    "tarefas_atrasadas", "tarefas_criadas_por_dia", "tarefas_concluidas_por_dia",
]


def _table(cols, rws):
    return {"type": "table", "columns": [{"text": n, "type": t} for n, t in cols], "rows": rws}


def _range(rng):
    try:
        f = date.fromisoformat(str(rng.get("from"))[:10])
        t = date.fromisoformat(str(rng.get("to"))[:10])
    except (ValueError, AttributeError):
        t = date.today()
        f = t - timedelta(days=30)
    if (t - f).days > 366:
        f = t - timedelta(days=366)
    return f, t


def grafana_target(conn, name, rng):
    s = compute_stats(conn)
    if name == "resumo":
        return _table(
            [("Total", "number"), ("Concluídas", "number"), ("Atrasadas", "number"),
             ("Em andamento", "number"), ("% concluído", "number")],
            [[s["total"], s["done"], s["overdue"], s["in_progress"], s["completion_rate"]]],
        )
    if name == "tarefas_por_status":
        return _table([("Status", "string"), ("Tarefas", "number")], [[x["name"], x["count"]] for x in s["by_status"]])
    if name == "tarefas_por_prioridade":
        return _table([("Prioridade", "string"), ("Tarefas", "number")], [[x["name"], x["count"]] for x in s["by_priority"]])
    if name == "tarefas_por_responsavel":
        return _table(
            [("Responsável", "string"), ("Total", "number"), ("Concluídas", "number"), ("Horas pendentes", "number")],
            [[x["name"], x["total"], x["done"], x["hours"]] for x in s["by_assignee"]],
        )
    if name == "tarefas_atrasadas":
        return _table(
            [("Tarefa", "string"), ("Quadro", "string"), ("Responsável", "string"), ("Prazo", "string"), ("Prioridade", "string")],
            [[x["title"], x["board_name"], x["assignee_name"], x["due_date"], x["priority"]] for x in s["overdue_tasks"]],
        )
    if name in ("tarefas_criadas_por_dia", "tarefas_concluidas_por_dia"):
        key = "created_at" if name == "tarefas_criadas_por_dia" else "completed_at"
        counts = Counter((t[key] or "")[:10] for t in load_tasks(conn) if t[key])
        f, t = _range(rng)
        pts, d = [], f
        while d <= t:
            ms = int(datetime(d.year, d.month, d.day, tzinfo=timezone.utc).timestamp() * 1000)
            pts.append([counts.get(d.isoformat(), 0), ms])
            d += timedelta(days=1)
        return {"target": name, "datapoints": pts}
    return {"target": name, "datapoints": []}


@app.route("/api/grafana/<token>", methods=["GET", "POST", "OPTIONS"])
@app.route("/api/grafana/<token>/", methods=["GET", "POST", "OPTIONS"])
def grafana_root(token):
    if request.method == "OPTIONS":
        return "", 204
    require_token(token)
    return "OK"


@app.route("/api/grafana/<token>/search", methods=["POST", "OPTIONS"])
def grafana_search(token):
    if request.method == "OPTIONS":
        return "", 204
    require_token(token)
    return jsonify(GRAFANA_METRICS)


@app.route("/api/grafana/<token>/query", methods=["POST", "OPTIONS"])
def grafana_query(token):
    if request.method == "OPTIONS":
        return "", 204
    require_token(token)
    d = request.get_json(silent=True) or {}
    conn = get_db()
    out = []
    for t in d.get("targets", []):
        name = t.get("target")
        if name in GRAFANA_METRICS:
            out.append(grafana_target(conn, name, d.get("range") or {}))
    return jsonify(out)


@app.route("/api/grafana/<token>/annotations", methods=["POST", "OPTIONS"])
def grafana_annotations(token):
    if request.method == "OPTIONS":
        return "", 204
    require_token(token)
    return jsonify([])


# ----------------------------------------------------------------------------
# Banco inicial
# ----------------------------------------------------------------------------
def seed(conn):
    def ts(days_ago, hour=10):
        d = datetime.now().replace(hour=hour, minute=0, second=0, microsecond=0) - timedelta(days=days_ago)
        return d.isoformat(timespec="seconds")

    def dd(offset):
        return (date.today() + timedelta(days=offset)).isoformat()

    mem = [
        ("Ana Souza", "ana@exemplo.com", "Gerente de projetos", MEMBER_COLORS[0]),
        ("Bruno Lima", "bruno@exemplo.com", "Desenvolvedor back-end", MEMBER_COLORS[1]),
        ("Carla Mendes", "carla@exemplo.com", "Marketing e suporte", MEMBER_COLORS[2]),
        ("Diego Alves", "diego@exemplo.com", "Designer", MEMBER_COLORS[3]),
    ]
    ids = [conn.execute("INSERT INTO members(name,email,role,color) VALUES(?,?,?,?)", m).lastrowid for m in mem]
    A, B, C, D = ids

    b1 = conn.execute(
        "INSERT INTO boards(name,description,color,statuses,created_at) VALUES(?,?,?,?,?)",
        ("Lançamento do produto", "Do escopo ao go-live", "#3b5bff", json.dumps(DEFAULT_STATUSES, ensure_ascii=False), ts(14)),
    ).lastrowid
    b2 = conn.execute(
        "INSERT INTO boards(name,description,color,statuses,created_at) VALUES(?,?,?,?,?)",
        ("Suporte técnico", "Chamados dos clientes", "#22b573",
         json.dumps(["Novo", "Em atendimento", "Aguardando cliente", "Resolvido"], ensure_ascii=False), ts(10)),
    ).lastrowid

    # (quadro, título, descrição, status, prioridade, resp, início, prazo, progresso, horas, tags, criada(dias atrás), concluída(dias atrás))
    T = [
        (b1, "Definir escopo do MVP", "Lista final de funcionalidades da primeira versão.", "Concluído", "Alta", A, -12, -8, 100, 8, "planejamento", 14, 8),
        (b1, "Pesquisa com clientes", "Entrevistas com 10 clientes atuais.", "Concluído", "Média", C, -10, -5, 100, 12, "pesquisa", 13, 5),
        (b1, "Configurar CI/CD", "Pipeline de build e deploy automático.", "Concluído", "Média", B, -9, -6, 100, 8, "devops", 11, 6),
        (b1, "Treinamento do time de suporte", "", "Concluído", "Baixa", C, -6, -3, 100, 6, "suporte", 9, 3),
        (b1, "Design das telas principais", "Protótipo navegável das 6 telas principais.", "Em revisão", "Alta", D, -6, 1, 80, 20, "design", 9, None),
        (b1, "Implementar autenticação", "Login, recuperação de senha e sessões.", "Em andamento", "Urgente", B, -4, 2, 55, 16, "backend", 8, None),
        (b1, "Integração com gateway de pagamento", "", "Em andamento", "Alta", B, -2, 6, 30, 24, "backend,financeiro", 6, None),
        (b1, "Relatório de métricas semanais", "", "Em andamento", "Média", A, -3, -1, 40, 5, "gestão", 7, None),
        (b1, "Revisar contrato do fornecedor", "", "A fazer", "Urgente", A, -2, -1, 0, 3, "jurídico", 2, None),
        (b1, "Landing page", "Página de captura com formulário.", "A fazer", "Média", D, 1, 9, 0, 12, "marketing,design", 5, None),
        (b1, "Plano de comunicação", "", "A fazer", "Baixa", C, 3, 12, 0, 6, "marketing", 4, None),
        (b1, "Testes de carga", "", "A fazer", "Alta", B, 5, 14, 0, 10, "qa", 3, None),
        (b2, "Cliente sem acesso ao painel", "Erro 403 após troca de senha.", "Em atendimento", "Urgente", B, -1, 0, 50, 2, "acesso", 2, None),
        (b2, "Dúvida sobre emissão de nota fiscal", "", "Aguardando cliente", "Média", C, -3, 2, 60, 1, "financeiro", 4, None),
        (b2, "Relatório exportado com datas erradas", "", "Novo", "Alta", None, None, 3, 0, 3, "bug", 1, None),
        (b2, "Solicitação de novo usuário", "", "Resolvido", "Baixa", C, -5, -4, 100, 1, "conta", 6, 4),
        (b2, "Lentidão na tela de relatórios", "", "Resolvido", "Alta", B, -8, -6, 100, 6, "performance", 9, 6),
    ]
    for i, t in enumerate(T):
        bid, title, desc, status, prio, resp, s, e, prog, hrs, tags, created, done = t
        conn.execute(
            """INSERT INTO tasks(board_id,title,description,status,priority,assignee_id,start_date,due_date,progress,
               estimate_h,tags,link,position,created_at,updated_at,completed_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (bid, title, desc, status, prio, resp, dd(s) if s is not None else None, dd(e), prog, hrs, tags, "", i,
             ts(created), ts(done if done is not None else created), ts(done) if done is not None else None),
        )
        log(conn, bid, None, 'Tarefa "%s" criada' % title)
    conn.execute("INSERT INTO comments(task_id,author,text,created_at) VALUES(5,'Ana Souza','Pode subir o protótipo no Drive e colar o link aqui?',?)", (ts(1),))
    conn.execute("INSERT INTO comments(task_id,author,text,created_at) VALUES(5,'Diego Alves','Feito, falta só ajustar o fluxo de cadastro.',?)", (ts(0),))
    A_ = [
        (b1, "Ao concluir, marcar progresso 100%", "status_changed", "Concluído", "set_progress", "100", 1),
        (b1, "Tarefa atrasada vira Urgente", "overdue", "", "set_priority", "Urgente", 1),
        (b1, "Avisar no Slack ao concluir", "status_changed", "Concluído", "notify_slack", '✅ {responsavel} concluiu "{titulo}" ({quadro})', 0),
        (b2, "Resolvido: comentar na tarefa", "status_changed", "Resolvido", "add_comment", "Chamado resolvido. Obrigado!", 1),
    ]
    for a in A_:
        conn.execute(
            "INSERT INTO automations(board_id,name,trigger_type,trigger_value,action_type,action_value,enabled) VALUES(?,?,?,?,?,?,?)", a
        )


def init_db():
    conn = connect()
    conn.executescript(SCHEMA)
    if not get_setting(conn, "api_token"):
        set_setting(conn, "api_token", secrets.token_urlsafe(24))
    if conn.execute("SELECT COUNT(*) FROM boards").fetchone()[0] == 0 and os.environ.get("TEAMFLOW_SEED", "1") != "0":
        seed(conn)
    conn.commit()
    conn.close()


init_db()

if __name__ == "__main__":
    start_scheduler()
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "5000"))
    print("\n  TeamFlow rodando em http://%s:%s\n" % (host if host != "0.0.0.0" else "localhost", port))
    app.run(host=host, port=port, debug=False, threaded=True)
