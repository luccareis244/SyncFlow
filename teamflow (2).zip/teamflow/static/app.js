'use strict';
/* TeamFlow - interface (JS puro, sem dependências externas) */

// ---------------------------------------------------------------- utilidades
const $ = (s, el = document) => el.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pad = n => String(n).padStart(2, '0');
const iso = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const pd = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
const fmt = s => (s ? `${s.slice(8, 10)}/${s.slice(5, 7)}` : '');
const fmtFull = s => (s ? `${s.slice(8, 10)}/${s.slice(5, 7)}/${s.slice(0, 4)}` : '');
const todayIso = () => iso(new Date());
const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
const initials = n => String(n || '?').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
const DAY = 864e5;

function ago(s) {
  const d = new Date(s), sec = (Date.now() - d) / 1000;
  if (isNaN(sec)) return '';
  if (sec < 60) return 'agora';
  if (sec < 3600) return Math.floor(sec / 60) + ' min';
  if (sec < 86400) return Math.floor(sec / 3600) + ' h';
  return d.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });
}

const ICONS = {
  kanban: '<rect x="3" y="3" width="5" height="14" rx="1"/><rect x="10" y="3" width="5" height="9" rx="1"/><rect x="17" y="3" width="4" height="11" rx="1"/>',
  table: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M9 4v16"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  gantt: '<path d="M4 6h8M8 12h10M6 18h9" stroke-width="4"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  bolt: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.5 3-6 6.5-6s6.5 2.5 6.5 6"/><path d="M16 5a3 3 0 0 1 0 6M18 14c2.2.7 3.5 2.7 3.5 5"/>',
  plug: '<path d="M9 2v6M15 2v6M6 8h12v3a6 6 0 0 1-12 0zM12 17v5"/>',
  activity: '<path d="M3 12h4l3-8 4 16 3-8h4"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  panel: '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  pencil: '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h8"/>',
  search: '<circle cx="11" cy="11" r="6"/><path d="m20 20-4-4"/>',
  link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
  chat: '<path d="M4 5h16v11H9l-5 4z"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  left: '<path d="m15 6-6 6 6 6"/>',
  right: '<path d="m9 6 6 6-6 6"/>',
  download: '<path d="M12 4v11M7 11l5 5 5-5M4 20h16"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
};
const ico = n => `<svg class="i" viewBox="0 0 24 24" aria-hidden="true">${ICONS[n] || ''}</svg>`;

const PRIOS = ['Baixa', 'Média', 'Alta', 'Urgente'];
const PCOL = { Baixa: '#8b93a7', 'Média': '#3b5bff', Alta: '#f5a524', Urgente: '#e5484d' };
const MID = ['#3b5bff', '#f5a524', '#8b5cf6', '#0ea5e9', '#ec4899', '#14b8a6'];
const MEMBER_COLORS = ['#ff5a3c', '#2f6fed', '#22b573', '#a855f7', '#f5a524', '#0ea5e9', '#ec4899'];

async function api(method, url, body) {
  const r = await fetch(url, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : {},
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null;
  try { data = await r.json(); } catch (e) { /* sem corpo */ }
  if (!r.ok) throw new Error((data && data.erro) || 'Erro ' + r.status);
  return data;
}

let toastTimer;
function toast(msg, err) {
  const t = $('#toast');
  t.textContent = msg;
  t.className = err ? 'err' : '';
  t.style.display = 'block';
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.style.display = 'none'), err ? 5000 : 2500);
}

// ---------------------------------------------------------------- estado
const S = {
  boards: [], members: [], tasks: [], autos: [], settings: { embeds: [] },
  page: 'overview', boardId: null, view: 'kanban',
  f: { q: '', who: '', prio: '' },
  cal: new Date(new Date().getFullYear(), new Date().getMonth(), 1),
  sort: { k: 'due_date', d: 1 }, gz: 28,
};
const board = () => S.boards.find(b => b.id === S.boardId);
const boardOf = id => S.boards.find(b => b.id === id);
const member = id => S.members.find(m => m.id === id);
const taskById = id => S.tasks.find(t => t.id === id);

function statusColor(b, s) {
  if (!b) return '#8b93a7';
  const i = b.statuses.indexOf(s);
  if (i <= 0) return '#8b93a7';
  if (i === b.statuses.length - 1) return '#22b573';
  return MID[(i - 1) % MID.length];
}
function statusColorByName(s) {
  for (const b of S.boards) if (b.statuses.includes(s)) return statusColor(b, s);
  return '#8b93a7';
}
const avatar = m => (m ? `<span class="avatar" style="background:${esc(m.color)}" title="${esc(m.name)}">${esc(initials(m.name))}</span>` : '');

async function load() {
  const [boards, members, tasks, autos, settings] = await Promise.all([
    api('GET', '/api/boards'), api('GET', '/api/members'), api('GET', '/api/tasks'),
    api('GET', '/api/automations'), api('GET', '/api/settings'),
  ]);
  Object.assign(S, { boards, members, tasks, autos, settings });
  if (S.page === 'board' && !board()) { S.page = boards.length ? 'board' : 'overview'; S.boardId = boards.length ? boards[0].id : null; }
}
async function refresh() { await load(); render(); }

// ---------------------------------------------------------------- layout
function render() { renderSide(); renderTop(); renderContent(); }

function renderSide() {
  const nav = (page, icon, label) =>
    `<button class="nav ${S.page === page ? 'on' : ''}" data-act="nav" data-page="${page}">${ico(icon)}${label}</button>`;
  $('#side').innerHTML = `
    <div class="brand"><span class="logo">${ico('kanban')}</span>TeamFlow</div>
    ${nav('overview', 'grid', 'Visão geral')}
    <div class="side-title">Quadros <button data-act="new-board" title="Novo quadro" aria-label="Novo quadro">${ico('plus')}</button></div>
    ${S.boards.map(b => `<button class="nav ${S.page === 'board' && S.boardId === b.id ? 'on' : ''}" data-act="open-board" data-id="${b.id}">
      <span class="dot" style="background:${esc(b.color)}"></span><span>${esc(b.name)}</span><span class="cnt">${b.task_count}</span></button>`).join('')}
    <div class="side-title">Espaço de trabalho</div>
    ${nav('team', 'users', 'Equipe')}
    ${nav('panels', 'panel', 'Painéis Power BI e Grafana')}
    ${nav('integrations', 'plug', 'Integrações')}
    ${nav('activity', 'activity', 'Atividade')}
    <div class="side-foot">Os dados ficam salvos neste computador.</div>`;
}

const VIEWS = [['kanban', 'kanban', 'Kanban'], ['table', 'table', 'Tabela'], ['calendar', 'calendar', 'Calendário'], ['gantt', 'gantt', 'Cronograma'], ['dashboard', 'chart', 'Dashboard']];

function renderTop() {
  const titles = {
    overview: ['Visão geral', 'Resumo de todos os quadros'],
    team: ['Equipe', 'Pessoas e carga de trabalho'],
    panels: ['Painéis Power BI e Grafana', 'Exiba seus painéis externos dentro do TeamFlow'],
    integrations: ['Integrações', 'Power BI, Grafana, Slack e outras ferramentas'],
    activity: ['Atividade', 'Histórico de mudanças'],
  };
  const burger = `<button class="burger icon-btn" data-act="menu" aria-label="Abrir menu">${ico('menu')}</button>`;
  if (S.page === 'board' && board()) {
    const b = board();
    const nAuto = S.autos.filter(a => a.board_id === b.id && a.enabled).length;
    $('#top').innerHTML = `
      <div class="top-row">${burger}
        <div><h1>${esc(b.name)}</h1>${b.description ? `<p class="sub">${esc(b.description)}</p>` : ''}</div>
        <button class="icon-btn" data-act="edit-board" title="Editar quadro" aria-label="Editar quadro">${ico('pencil')}</button>
        <span class="grow"></span>
        <button class="btn" data-act="automations">${ico('bolt')}Automações${nAuto ? ` (${nAuto})` : ''}</button>
        <button class="btn primary" data-act="new-task">${ico('plus')}Nova tarefa</button>
      </div>
      <div class="tabs" role="tablist">${VIEWS.map(([k, i, l]) =>
        `<button class="tab ${S.view === k ? 'on' : ''}" role="tab" aria-selected="${S.view === k}" data-act="view" data-v="${k}">${ico(i)}${l}</button>`).join('')}</div>`;
  } else {
    const [h, sub] = titles[S.page] || titles.overview;
    $('#top').innerHTML = `<div class="top-row" style="padding-bottom:14px">${burger}<div><h1>${h}</h1><p class="sub">${sub}</p></div><span class="grow"></span>
      ${S.page === 'team' ? `<button class="btn primary" data-act="new-member">${ico('plus')}Adicionar pessoa</button>` : ''}
      ${S.page === 'overview' ? `<button class="btn primary" data-act="new-board">${ico('plus')}Novo quadro</button>` : ''}</div>`;
  }
}

function renderContent() {
  const c = $('#content');
  if (S.page === 'board' && board()) {
    const b = board();
    const showFilters = S.view !== 'dashboard';
    c.innerHTML = (showFilters ? `<div class="filters">
      <label class="field-search">${ico('search')}<input type="text" data-input="q" placeholder="Buscar tarefa" value="${esc(S.f.q)}" aria-label="Buscar tarefa"></label>
      <select data-change="who" aria-label="Filtrar por responsável"><option value="">Todos os responsáveis</option><option value="none" ${S.f.who === 'none' ? 'selected' : ''}>Sem responsável</option>
        ${S.members.map(m => `<option value="${m.id}" ${S.f.who === String(m.id) ? 'selected' : ''}>${esc(m.name)}</option>`).join('')}</select>
      <select data-change="prio" aria-label="Filtrar por prioridade"><option value="">Todas as prioridades</option>${PRIOS.map(p => `<option ${S.f.prio === p ? 'selected' : ''}>${p}</option>`).join('')}</select>
      ${S.f.q || S.f.who || S.f.prio ? `<button class="btn ghost sm" data-act="clear-filters">Limpar filtros</button>` : ''}
      ${S.view === 'table' ? `<span class="grow" style="flex:1"></span><a class="btn sm" download="tarefas.csv" href="/api/bi/tasks.csv?token=${encodeURIComponent(S.settings.api_token || '')}&board_id=${b.id}">${ico('download')}Exportar CSV</a>` : ''}
    </div>` : '') + '<div id="view"></div>';
    renderView();
  } else if (S.page === 'overview') {
    c.innerHTML = S.boards.length ? '<div id="view"></div>' : `<div class="empty"><b>Comece criando um quadro</b>Um quadro reúne as tarefas de um projeto ou time.<br><br><button class="btn primary" data-act="new-board">${ico('plus')}Novo quadro</button></div>`;
    if (S.boards.length) viewDashboard($('#view'), null);
  } else if (S.page === 'team') viewTeam(c);
  else if (S.page === 'panels') viewPanels(c);
  else if (S.page === 'integrations') viewIntegrations(c);
  else if (S.page === 'activity') viewActivity(c);
}

function renderView() {
  const el = $('#view');
  if (!el) return;
  ({ kanban: viewKanban, table: viewTable, calendar: viewCalendar, gantt: viewGantt, dashboard: v => viewDashboard(v, S.boardId) }[S.view])(el);
}

function visibleTasks() {
  const q = S.f.q.trim().toLowerCase();
  return S.tasks.filter(t => t.board_id === S.boardId
    && (!q || (t.title + ' ' + t.tags + ' ' + t.description).toLowerCase().includes(q))
    && (!S.f.who || (S.f.who === 'none' ? !t.assignee_id : String(t.assignee_id) === S.f.who))
    && (!S.f.prio || t.priority === S.f.prio));
}

const emptyBox = (t, s) => `<div class="empty"><b>${t}</b>${s}</div>`;

// ---------------------------------------------------------------- Kanban
function cardHtml(t, b) {
  const m = member(t.assignee_id);
  const tags = t.tags ? t.tags.split(',').map(x => `<span class="tag">${esc(x)}</span>`).join('') : '';
  return `<article class="tcard" draggable="true" data-id="${t.id}" data-act="open-task" style="--p:${PCOL[t.priority]}" tabindex="0">
    <div class="t">${esc(t.title)}</div>
    ${tags ? `<div class="tags">${tags}</div>` : ''}
    <div class="meta">
      ${t.due_date ? `<span class="due ${t.overdue ? 'late' : ''}" title="Prazo">${ico('clock')}${fmt(t.due_date)}</span>` : ''}
      <span>${esc(t.priority)}</span>
      ${t.comment_count ? `<span title="Comentários">${ico('chat')}${t.comment_count}</span>` : ''}
      ${t.link ? `<span title="Tem link">${ico('link')}</span>` : ''}
      <span class="sp"></span>${avatar(m)}
    </div>
    ${t.progress ? `<div class="bar" title="${t.progress}%"><i style="width:${t.progress}%"></i></div>` : ''}
  </article>`;
}

function viewKanban(el) {
  const b = board(), ts = visibleTasks();
  el.innerHTML = '<div class="kanban">' + b.statuses.map(s => {
    const col = ts.filter(t => t.status === s).sort((x, y) => x.position - y.position);
    return `<section class="col" data-status="${esc(s)}" aria-label="${esc(s)}">
      <div class="col-head" style="--c:${statusColor(b, s)}">${esc(s)}<span class="n">${col.length}</span></div>
      <div class="col-body">${col.map(t => cardHtml(t, b)).join('')}</div>
      <button class="add-card" data-act="new-task" data-status="${esc(s)}">+ Adicionar tarefa</button></section>`;
  }).join('') + '</div>';
}

// arrastar e soltar
let dragId = null;
document.addEventListener('dragstart', e => {
  const c = e.target.closest && e.target.closest('.tcard');
  if (!c) return;
  dragId = +c.dataset.id;
  c.classList.add('drag');
  e.dataTransfer.effectAllowed = 'move';
  e.dataTransfer.setData('text/plain', String(dragId));
});
document.addEventListener('dragend', () => {
  document.querySelectorAll('.drag,.over').forEach(x => x.classList.remove('drag', 'over'));
  dragId = null;
});
document.addEventListener('dragover', e => {
  const col = e.target.closest && e.target.closest('.col');
  if (!col || !dragId) return;
  e.preventDefault();
  document.querySelectorAll('.col.over').forEach(x => x !== col && x.classList.remove('over'));
  col.classList.add('over');
});
document.addEventListener('drop', async e => {
  const col = e.target.closest && e.target.closest('.col');
  if (!col || !dragId) return;
  e.preventDefault();
  const id = dragId, status = col.dataset.status;
  const cards = [...col.querySelectorAll('.tcard:not(.drag)')];
  let idx = cards.findIndex(c => { const r = c.getBoundingClientRect(); return e.clientY < r.top + r.height / 2; });
  if (idx < 0) idx = cards.length;
  const ids = cards.map(c => +c.dataset.id);
  const prev = idx > 0 ? taskById(ids[idx - 1]).position : null;
  const next = idx < ids.length ? taskById(ids[idx]).position : null;
  const position = prev === null && next === null ? 0 : prev === null ? next - 1 : next === null ? prev + 1 : (prev + next) / 2;
  try { await api('PUT', '/api/tasks/' + id, { status, position }); await refresh(); } catch (err) { toast(err.message, true); }
});

// ---------------------------------------------------------------- Tabela
function viewTable(el) {
  const b = board(), { k, d } = S.sort;
  const ts = visibleTasks().sort((x, y) => {
    let a = x[k], c = y[k];
    if (k === 'priority') { a = PRIOS.indexOf(a); c = PRIOS.indexOf(c); }
    if (k === 'status') { a = b.statuses.indexOf(a); c = b.statuses.indexOf(c); }
    if (a == null || a === '') return 1;
    if (c == null || c === '') return -1;
    return (a > c ? 1 : a < c ? -1 : 0) * d;
  });
  const th = (key, label) => `<th data-act="sort" data-k="${key}" aria-sort="${k === key ? (d > 0 ? 'ascending' : 'descending') : 'none'}">${label}${k === key ? (d > 0 ? ' ↑' : ' ↓') : ''}</th>`;
  el.innerHTML = ts.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr>
    ${th('title', 'Tarefa')}${th('status', 'Status')}${th('priority', 'Prioridade')}${th('assignee_name', 'Responsável')}${th('start_date', 'Início')}${th('due_date', 'Prazo')}${th('progress', 'Progresso')}${th('estimate_h', 'Horas')}<th>Etiquetas</th></tr></thead><tbody>
    ${ts.map(t => `<tr>
      <td class="title"><button data-act="open-task" data-id="${t.id}">${esc(t.title)}</button></td>
      <td><select class="stat" data-change="field" data-f="status" data-id="${t.id}" style="background:${statusColor(b, t.status)}" aria-label="Status">${b.statuses.map(s => `<option ${s === t.status ? 'selected' : ''}>${esc(s)}</option>`).join('')}</select></td>
      <td><select data-change="field" data-f="priority" data-id="${t.id}" aria-label="Prioridade" style="border-left:4px solid ${PCOL[t.priority]}">${PRIOS.map(p => `<option ${p === t.priority ? 'selected' : ''}>${p}</option>`).join('')}</select></td>
      <td><select data-change="field" data-f="assignee_id" data-id="${t.id}" aria-label="Responsável"><option value="">—</option>${S.members.map(m => `<option value="${m.id}" ${m.id === t.assignee_id ? 'selected' : ''}>${esc(m.name)}</option>`).join('')}</select></td>
      <td><input type="date" data-change="field" data-f="start_date" data-id="${t.id}" value="${esc(t.start_date || '')}" aria-label="Início"></td>
      <td><input type="date" data-change="field" data-f="due_date" data-id="${t.id}" value="${esc(t.due_date || '')}" aria-label="Prazo" ${t.overdue ? 'style="color:var(--red);font-weight:700"' : ''}></td>
      <td><div class="prog"><div class="bar"><i style="width:${t.progress}%"></i></div><span class="muted">${t.progress}%</span></div></td>
      <td>${t.estimate_h ? t.estimate_h + ' h' : '—'}</td>
      <td>${t.tags ? t.tags.split(',').map(x => `<span class="tag">${esc(x)}</span>`).join(' ') : ''}</td></tr>`).join('')}
    </tbody></table></div>` : emptyBox('Nenhuma tarefa encontrada', 'Crie uma tarefa ou limpe os filtros.');
}

// ---------------------------------------------------------------- Calendário
function viewCalendar(el) {
  const b = board(), y = S.cal.getFullYear(), m = S.cal.getMonth();
  const start = new Date(y, m, 1 - new Date(y, m, 1).getDay());
  const by = {};
  visibleTasks().filter(t => t.due_date).forEach(t => (by[t.due_date] = by[t.due_date] || []).push(t));
  const td = todayIso();
  let cells = '';
  for (let i = 0; i < 42; i++) {
    const d = new Date(start.getFullYear(), start.getMonth(), start.getDate() + i), k = iso(d);
    cells += `<div class="day ${d.getMonth() !== m ? 'out' : ''} ${k === td ? 'today' : ''}" data-act="new-task" data-due="${k}">
      <span class="num">${d.getDate()}</span>
      ${(by[k] || []).map(t => `<button class="chip ${t.done ? 'done' : ''}" style="--p:${statusColor(b, t.status)}" data-act="open-task" data-id="${t.id}" title="${esc(t.title)}">${esc(t.title)}</button>`).join('')}</div>`;
  }
  el.innerHTML = `<div class="cal-head">
    <button class="btn sm" data-act="cal" data-d="-1" aria-label="Mês anterior">${ico('left')}</button>
    <h2>${cap(S.cal.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' }))}</h2>
    <button class="btn sm" data-act="cal" data-d="1" aria-label="Próximo mês">${ico('right')}</button>
    <button class="btn sm ghost" data-act="cal" data-d="0">Hoje</button>
    <span class="muted" style="margin-left:auto">Mostra os prazos. Clique em um dia para criar uma tarefa.</span></div>
    <div class="cal">${['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'].map(d => `<div class="dow">${d}</div>`).join('')}${cells}</div>`;
}

// ---------------------------------------------------------------- Cronograma
function viewGantt(el) {
  const b = board(), ts = visibleTasks();
  const dated = ts.filter(t => t.start_date || t.due_date).sort((x, y) => (x.start_date || x.due_date).localeCompare(y.start_date || y.due_date));
  const undated = ts.filter(t => !t.start_date && !t.due_date);
  if (!dated.length) { el.innerHTML = emptyBox('Nenhuma tarefa com datas', 'Defina início e prazo nas tarefas para vê-las no cronograma.'); return; }
  const dw = S.gz, now = pd(todayIso());
  let min = now, max = now;
  dated.forEach(t => {
    const s = pd(t.start_date || t.due_date), e = pd(t.due_date || t.start_date);
    if (s < min) min = s; if (e > max) max = e;
  });
  min = new Date(min.getTime() - 3 * DAY); max = new Date(max.getTime() + 6 * DAY);
  const days = Math.round((max - min) / DAY) + 1, W = days * dw;
  const off = d => Math.round((d - min) / DAY) * dw;
  let head = '';
  for (let i = 0; i < days; i++) {
    const d = new Date(min.getFullYear(), min.getMonth(), min.getDate() + i);
    if (i === 0 || d.getDate() === 1) head += `<span class="g-month" style="left:${i * dw + 4}px">${cap(d.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' }))}</span>`;
    if (dw >= 22 || d.getDay() === 1) head += `<span class="g-day" style="left:${i * dw}px;width:${dw}px">${d.getDate()}</span>`;
  }
  const todayLine = `<div class="g-today" style="left:${off(now) + dw / 2 - 1}px"></div>`;
  const row = t => {
    const s = pd(t.start_date || t.due_date), e = pd(t.due_date || t.start_date);
    const left = off(s), width = Math.max(dw, off(e) + dw - left) - 2;
    const m = member(t.assignee_id);
    return `<div class="g-row"><div class="g-label" title="${esc(t.title)}">${avatar(m)}<span style="overflow:hidden;text-overflow:ellipsis">${esc(t.title)}</span></div>
      <div class="g-track grid" style="width:${W}px;background-size:${dw}px 100%">${todayLine}
      <button class="g-bar" data-act="open-task" data-id="${t.id}" style="left:${left}px;width:${width}px;background:${statusColor(b, t.status)}" title="${esc(t.title)} — ${fmtFull(t.start_date) || '?'} a ${fmtFull(t.due_date) || '?'} (${t.progress}%)">
        <i class="fill" style="width:${t.progress}%"></i>${width > 70 ? `<span>${esc(t.title)}</span>` : ''}</button></div></div>`;
  };
  el.innerHTML = `<div class="cal-head"><span class="muted">Barras coloridas seguem a coluna da tarefa; a faixa clara mostra o progresso.</span>
    <span style="margin-left:auto" class="row"><button class="btn sm" data-act="zoom" data-d="-6" aria-label="Diminuir zoom">−</button><button class="btn sm" data-act="zoom" data-d="6" aria-label="Aumentar zoom">+</button></span></div>
    <div class="gantt-wrap" id="gwrap"><div style="width:${W + 240}px">
      <div class="g-row head"><div class="g-label">Tarefa</div><div class="g-track" style="width:${W}px">${head}${todayLine}</div></div>
      ${dated.map(row).join('')}</div></div>
    ${undated.length ? `<p class="muted" style="margin-top:12px">Sem datas: ${undated.map(t => `<button class="btn sm ghost" data-act="open-task" data-id="${t.id}">${esc(t.title)}</button>`).join('')}</p>` : ''}`;
  const w = $('#gwrap');
  if (w) w.scrollLeft = Math.max(0, off(now) - 260);
}

// ---------------------------------------------------------------- Dashboard
function hbars(items, colorFn) {
  const max = Math.max(1, ...items.map(i => i.count));
  return items.map(i => `<div class="hbar"><span class="nm" title="${esc(i.name)}">${esc(i.name)}</span>
    <span class="tr"><i style="width:${(i.count / max) * 100}%;background:${colorFn(i)}"></i></span><span class="v">${i.count}</span></div>`).join('');
}

function lineChart(created, completed) {
  const W = 520, H = 190, L = 28, B = 24, T = 10, R = 8;
  const n = created.length, max = Math.max(2, ...created.map(x => x.count), ...completed.map(x => x.count));
  const x = i => L + (i * (W - L - R)) / Math.max(1, n - 1), y = v => T + (H - T - B) * (1 - v / max);
  const line = (arr, c) => `<polyline fill="none" stroke="${c}" stroke-width="2.5" stroke-linejoin="round" points="${arr.map((p, i) => `${x(i)},${y(p.count)}`).join(' ')}"/>` +
    arr.map((p, i) => `<circle cx="${x(i)}" cy="${y(p.count)}" r="3" fill="${c}"><title>${fmt(p.date)}: ${p.count}</title></circle>`).join('');
  const grid = [0, Math.round(max / 2), max].map(v => `<line x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}" stroke="#e6eaf1"/><text x="${L - 6}" y="${y(v) + 4}" font-size="10" text-anchor="end" fill="#6a7389">${v}</text>`).join('');
  const lbl = created.map((p, i) => (i % 3 === 0 || i === n - 1 ? `<text x="${x(i)}" y="${H - 6}" font-size="10" text-anchor="middle" fill="#6a7389">${fmt(p.date)}</text>` : '')).join('');
  return `<svg viewBox="0 0 ${W} ${H}" width="100%" role="img" aria-label="Tarefas criadas e concluídas por dia">${grid}${lbl}${line(created, '#3b5bff')}${line(completed, '#22b573')}</svg>
    <div class="legend"><span><i style="background:#3b5bff"></i>Criadas</span><span><i style="background:#22b573"></i>Concluídas</span></div>`;
}

async function viewDashboard(el, boardId) {
  el.innerHTML = '<div class="empty">Carregando…</div>';
  const s = await api('GET', '/api/dashboard' + (boardId ? '?board_id=' + boardId : ''));
  if (!el.isConnected) return;
  const list = arr => arr.length ? arr.map(t => `<div class="list-row"><button class="lk" data-act="open-task" data-id="${t.id}">${esc(t.title)}</button>
    <span class="muted">${esc(t.assignee_name || '')}</span><span class="${s.overdue_tasks.includes(t) ? 'due late' : 'muted'}">${fmt(t.due_date)}</span></div>`).join('') : '<p class="muted">Nada por aqui.</p>';
  const maxA = Math.max(1, ...s.by_assignee.map(a => a.total));
  el.innerHTML = `
    <div class="kpis">
      <div class="kpi"><div class="v">${s.total}</div><div class="l">Tarefas no total</div></div>
      <div class="kpi"><div class="v">${s.in_progress}</div><div class="l">Em andamento</div></div>
      <div class="kpi"><div class="v">${s.done} <small style="font-size:16px;color:var(--muted)">${s.completion_rate}%</small></div><div class="l">Concluídas</div></div>
      <div class="kpi ${s.overdue ? 'late' : ''}"><div class="v">${s.overdue}</div><div class="l">Atrasadas</div></div>
    </div>
    <div class="grid2">
      <div class="card"><h3>Tarefas por status</h3>${hbars(s.by_status, i => statusColorByName(i.name))}</div>
      <div class="card"><h3>Criadas e concluídas (14 dias)</h3>${lineChart(s.created_per_day, s.completed_per_day)}</div>
      <div class="card"><h3>Carga por pessoa</h3>${s.by_assignee.filter(a => a.total).map(a => `<div class="hbar"><span class="nm">${esc(a.name)}</span>
        <span class="tr" title="${a.done} concluídas de ${a.total}"><i style="width:${(a.done / maxA) * 100}%;background:#22b573"></i><i style="width:${((a.total - a.done) / maxA) * 100}%;background:${esc(a.color)}"></i></span><span class="v">${a.total}</span></div>`).join('') || '<p class="muted">Sem tarefas atribuídas.</p>'}
        <div class="legend"><span><i style="background:#22b573"></i>Concluídas</span><span>Restante na cor da pessoa</span></div></div>
      <div class="card"><h3>Por prioridade</h3>${hbars(s.by_priority, i => PCOL[i.name])}</div>
      <div class="card"><h3>Atrasadas</h3>${list(s.overdue_tasks)}</div>
      <div class="card"><h3>Próximos 7 dias</h3>${list(s.upcoming)}</div>
    </div>`;
}

// ---------------------------------------------------------------- Equipe
function viewTeam(c) {
  c.innerHTML = S.members.length ? `<div class="members">${S.members.map(m => {
    const mine = S.tasks.filter(t => t.assignee_id === m.id);
    const done = mine.filter(t => t.done).length, late = mine.filter(t => t.overdue).length;
    const hrs = mine.filter(t => !t.done).reduce((a, t) => a + (t.estimate_h || 0), 0);
    return `<div class="card member"><div class="head">${avatar(m)}<div style="flex:1;min-width:0"><div class="nm">${esc(m.name)}</div><div class="muted">${esc(m.role || 'Sem cargo')}</div>${m.email ? `<div class="muted" style="font-size:12px">${esc(m.email)}</div>` : ''}</div>
      <button class="icon-btn" data-act="edit-member" data-id="${m.id}" aria-label="Editar ${esc(m.name)}">${ico('pencil')}</button></div>
      <div class="stats3"><span><b>${mine.length}</b>tarefas</span><span><b>${done}</b>concluídas</span><span><b style="${late ? 'color:var(--red)' : ''}">${late}</b>atrasadas</span><span><b>${Math.round(hrs * 10) / 10}</b>h pendentes</span></div></div>`;
  }).join('')}</div>` : emptyBox('Nenhuma pessoa cadastrada', 'Adicione as pessoas do time para atribuir tarefas.');
}

// ---------------------------------------------------------------- Painéis externos
function viewPanels(c) {
  const embeds = S.settings.embeds || [];
  c.innerHTML = `<div class="card embed"><h3>Adicionar painel</h3>
    <p class="muted" style="margin-top:0">Cole o link de incorporação do relatório (Power BI: Arquivo → Incorporar relatório; Grafana: Compartilhar → Link). No Grafana, ative <code>allow_embedding = true</code> no grafana.ini.</p>
    <div class="row"><input type="text" id="emb-name" placeholder="Nome (ex.: Indicadores do mês)" style="max-width:280px">
      <select id="emb-type" style="width:auto"><option value="powerbi">Power BI</option><option value="grafana">Grafana</option><option value="outro">Outro</option></select>
      <input type="url" id="emb-url" placeholder="https://…"><button class="btn primary" data-act="add-embed">Adicionar</button></div></div>
    ${embeds.length ? embeds.map((e, i) => `<div class="card embed"><div class="hd"><h3>${esc(e.name)}</h3><span class="tag">${e.type === 'powerbi' ? 'Power BI' : e.type === 'grafana' ? 'Grafana' : 'Outro'}</span>
      <a class="btn sm" href="${esc(e.url)}" target="_blank" rel="noopener noreferrer">Abrir em nova aba</a>
      <button class="icon-btn" data-act="del-embed" data-i="${i}" aria-label="Remover painel">${ico('trash')}</button></div>
      <iframe src="${esc(e.url)}" title="${esc(e.name)}" loading="lazy" referrerpolicy="no-referrer" sandbox="allow-scripts allow-same-origin allow-popups allow-forms"></iframe></div>`).join('')
    : emptyBox('Nenhum painel adicionado', 'Depois de adicionar, o painel aparece aqui, ao lado das suas tarefas.')}`;
}

// ---------------------------------------------------------------- Integrações
const codeBlock = txt => `<div class="code">${esc(txt)}<button data-act="copy" data-text="${esc(txt)}" aria-label="Copiar" title="Copiar">${ico('copy')}</button></div>`;

function viewIntegrations(c) {
  const base = location.origin, tok = S.settings.api_token || '';
  const u = p => `${base}/api/bi/${p}?token=${tok}`;
  const mcode = `let
    Fonte = Csv.Document(Web.Contents("${u('tasks.csv')}"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
    Tabela = Table.PromoteHeaders(Fonte, [PromoteAllScalars=true])
in
    Tabela`;
  c.innerHTML = `<div class="int-grid">
    <div class="card int"><h3>${ico('chart')}Power BI</h3>
      <p>No Power BI Desktop: <b>Obter dados → Web</b>, cole uma das URLs abaixo e escolha acesso <b>Anônimo</b>. Ou use <b>Obter dados → Consulta em branco → Editor Avançado</b> e cole o código M. Os dados são atualizados a cada atualização do relatório.</p>
      <div class="kv"><b>Tarefas (CSV)</b><span>${codeBlock(u('tasks.csv'))}</span><b>Tarefas (JSON)</b><span>${codeBlock(u('tasks.json'))}</span>
        <b>Pessoas</b><span>${codeBlock(u('members.csv'))}</span><b>Quadros</b><span>${codeBlock(u('boards.csv'))}</span></div>
      <p>Código M pronto:</p>${codeBlock(mcode)}
      <p class="hint">Para atualizar no serviço Power BI (nuvem), o TeamFlow precisa estar acessível pela internet ou por um gateway de dados local. Para filtrar um quadro, acrescente <code>&amp;board_id=1</code> às URLs de tarefas.</p></div>

    <div class="card int"><h3>${ico('activity')}Grafana</h3>
      <p><b>Opção 1 — plugin Infinity</b> (recomendado): crie uma fonte de dados Infinity e, na consulta, escolha tipo <b>JSON</b> ou <b>CSV</b>, método GET, com a URL:</p>${codeBlock(u('tasks.json'))}
      <p><b>Opção 2 — plugin SimpleJSON</b>: use esta URL como fonte de dados (o token já vai no caminho):</p>${codeBlock(`${base}/api/grafana/${tok}`)}
      <p>Métricas disponíveis: <span class="tag">resumo</span> <span class="tag">tarefas_por_status</span> <span class="tag">tarefas_por_prioridade</span> <span class="tag">tarefas_por_responsavel</span> <span class="tag">tarefas_atrasadas</span> <span class="tag">tarefas_criadas_por_dia</span> <span class="tag">tarefas_concluidas_por_dia</span></p>
      <p class="hint">Se o Grafana estiver em outro computador ou container, troque <code>${esc(location.host)}</code> pelo endereço da máquina do TeamFlow (inicie com <code>HOST=0.0.0.0</code>). Para ver painéis do Grafana ou Power BI dentro do TeamFlow, use <b>Painéis Power BI e Grafana</b> no menu.</p></div>

    <div class="card int"><h3>${ico('chat')}Slack</h3>
      <p>Crie um <b>Incoming Webhook</b> no Slack e cole a URL. Use-o em automações com a ação “Avisar no Slack”.</p>
      <div class="row"><input type="url" id="slack-url" placeholder="https://hooks.slack.com/services/…" value="${esc(S.settings.slack_webhook || '')}">
        <button class="btn primary" data-act="save-slack">Salvar</button><button class="btn" data-act="test-slack">Enviar teste</button></div></div>

    <div class="card int"><h3>${ico('plug')}Webhook geral (Zapier, n8n, Make, Jira, Google Drive)</h3>
      <p><b>Saída:</b> o TeamFlow envia um JSON para esta URL quando uma tarefa é criada, atualizada ou excluída. Conecte-a ao Zapier, n8n ou Make para criar issues no Jira, salvar arquivos no Google Drive e mais.</p>
      <div class="row"><input type="url" id="hook-url" placeholder="https://…" value="${esc(S.settings.webhook_url || '')}"><button class="btn primary" data-act="save-hook">Salvar</button></div>
      <p style="margin-top:14px"><b>Entrada:</b> envie um POST para criar tarefas a partir de outra ferramenta:</p>
      ${codeBlock(`curl -X POST "${base}/api/integrations/tasks?token=${tok}" -H "Content-Type: application/json" -d '{"board":"${esc(S.boards[0] ? S.boards[0].name : 'Meu quadro')}","title":"Nova tarefa","priority":"Alta","due_date":"${todayIso()}","link":"https://…"}'`)}
      <p class="hint">Dica: cole o link do arquivo do Drive ou do issue do Jira no campo “Link” da tarefa.</p></div>

    <div class="card int"><h3>Token de acesso</h3>
      <p>Protege as URLs de Power BI, Grafana e da entrada de tarefas. Quem tiver o token consegue ler os dados, então não o compartilhe.</p>
      ${codeBlock(tok)}<button class="btn danger" data-act="regen-token">Gerar novo token</button>
      <p class="hint">Ao gerar um novo token, atualize as URLs no Power BI e no Grafana.</p></div></div>`;
}

// ---------------------------------------------------------------- Atividade
async function viewActivity(c) {
  c.innerHTML = '<div class="empty">Carregando…</div>';
  const items = await api('GET', '/api/activity?limit=100');
  if (S.page !== 'activity') return;
  c.innerHTML = `<div class="card feed">${items.length ? items.map(a => `<div class="it"><span class="when">${ago(a.created_at)}</span><span>${esc(a.text)}</span></div>`).join('') : '<p class="muted">Sem atividade ainda.</p>'}</div>`;
}

// ---------------------------------------------------------------- Modais
function openModal(html, small) {
  $('#modal').innerHTML = `<div class="overlay" data-act="overlay"><div class="modal ${small ? 'sm' : ''}" role="dialog" aria-modal="true">${html}</div></div>`;
  const f = $('#modal input[type=text],#modal textarea');
  if (f) f.focus();
}
function closeModal() { $('#modal').innerHTML = ''; }
const modalHead = t => `<div class="modal-h"><h2>${t}</h2><button class="icon-btn" data-act="close" aria-label="Fechar">${ico('x')}</button></div>`;
function formData(root) {
  const o = {};
  root.querySelectorAll('[name]').forEach(el => { o[el.name] = el.value; });
  return o;
}

async function openTask(id, preset = {}) {
  const isNew = !id;
  const b0 = board();
  const t = isNew ? { board_id: S.boardId, title: '', description: '', status: preset.status || b0.statuses[0], priority: 'Média', assignee_id: '', start_date: '', due_date: preset.due || '', progress: 0, estimate_h: 0, tags: '', link: '' } : taskById(id);
  if (!t) return;
  const b = boardOf(t.board_id);
  openModal(`${modalHead(isNew ? 'Nova tarefa' : 'Editar tarefa')}
    <div class="modal-b"><div class="form" id="tform">
      <div class="full"><input class="title-in" type="text" name="title" placeholder="Título da tarefa" value="${esc(t.title)}" aria-label="Título" maxlength="300"></div>
      <div class="full"><label for="f-desc">Descrição</label><textarea id="f-desc" name="description">${esc(t.description)}</textarea></div>
      <div><label for="f-st">Status</label><select id="f-st" name="status">${b.statuses.map(s => `<option ${s === t.status ? 'selected' : ''}>${esc(s)}</option>`).join('')}</select></div>
      <div><label for="f-pr">Prioridade</label><select id="f-pr" name="priority">${PRIOS.map(p => `<option ${p === t.priority ? 'selected' : ''}>${p}</option>`).join('')}</select></div>
      <div><label for="f-as">Responsável</label><select id="f-as" name="assignee_id"><option value="">Sem responsável</option>${S.members.map(m => `<option value="${m.id}" ${m.id === t.assignee_id ? 'selected' : ''}>${esc(m.name)}</option>`).join('')}</select></div>
      <div><label for="f-h">Horas estimadas</label><input id="f-h" type="number" name="estimate_h" min="0" step="0.5" value="${t.estimate_h || 0}"></div>
      <div><label for="f-s">Início</label><input id="f-s" type="date" name="start_date" value="${esc(t.start_date || '')}"></div>
      <div><label for="f-d">Prazo</label><input id="f-d" type="date" name="due_date" value="${esc(t.due_date || '')}"></div>
      <div class="full"><label for="f-p">Progresso: <output id="f-pv">${t.progress}%</output></label><input id="f-p" type="range" name="progress" min="0" max="100" step="5" value="${t.progress}" style="width:100%"></div>
      <div><label for="f-t">Etiquetas (separadas por vírgula)</label><input id="f-t" type="text" name="tags" value="${esc(t.tags)}"></div>
      <div><label for="f-l">Link (Drive, Jira, etc.)</label><input id="f-l" type="url" name="link" placeholder="https://…" value="${esc(t.link)}"></div>
    </div>
    ${isNew ? '' : `<div class="cmts"><h3 style="font-size:16px;margin-bottom:10px">Comentários</h3><div id="cmt-list"><span class="muted">Carregando…</span></div>
      <div class="row" style="margin-top:8px"><input type="text" id="cmt-in" placeholder="Escreva um comentário" aria-label="Comentário"><button class="btn" data-act="add-comment" data-id="${t.id}">Comentar</button></div></div>`}</div>
    <div class="modal-f">${isNew ? '' : `<button class="btn danger" data-act="del-task" data-id="${t.id}">${ico('trash')}Excluir</button>`}<span class="sp"></span>
      <button class="btn" data-act="close">Cancelar</button><button class="btn primary" data-act="save-task" data-id="${id || ''}">Salvar</button></div>`);
  if (!isNew) loadComments(t.id);
}

async function loadComments(id) {
  const list = await api('GET', `/api/tasks/${id}/comments`);
  const el = $('#cmt-list');
  if (el) el.innerHTML = list.length ? list.map(c => `<div class="cmt"><div class="by">${esc(c.author)} · ${ago(c.created_at)}</div>${esc(c.text)}</div>`).join('') : '<span class="muted">Nenhum comentário ainda.</span>';
}

function openBoard(id) {
  const b = id ? boardOf(id) : { name: '', description: '', color: '#3b5bff', statuses: ['A fazer', 'Em andamento', 'Em revisão', 'Concluído'] };
  openModal(`${modalHead(id ? 'Editar quadro' : 'Novo quadro')}<div class="modal-b"><div class="form" id="bform">
    <div class="full"><label for="b-n">Nome</label><input id="b-n" type="text" name="name" value="${esc(b.name)}" maxlength="80"></div>
    <div class="full"><label for="b-d">Descrição</label><input id="b-d" type="text" name="description" value="${esc(b.description)}" maxlength="300"></div>
    <div><label for="b-c">Cor</label><input id="b-c" type="color" name="color" value="${esc(b.color)}"></div>
    <div class="full"><label for="b-s">Colunas (uma por linha; a última é a de concluído)</label><textarea id="b-s" name="statuses" rows="6">${esc(b.statuses.join('\n'))}</textarea>
      <p class="hint">${id ? 'Se você só renomear, as tarefas acompanham a coluna. Colunas removidas movem as tarefas para a primeira coluna.' : 'Você pode mudar as colunas depois.'}</p></div></div></div>
    <div class="modal-f">${id ? `<button class="btn danger" data-act="del-board" data-id="${id}">${ico('trash')}Excluir quadro</button>` : ''}<span class="sp"></span>
      <button class="btn" data-act="close">Cancelar</button><button class="btn primary" data-act="save-board" data-id="${id || ''}">Salvar</button></div>`, true);
}

function openMember(id) {
  const m = id ? member(id) : { name: '', email: '', role: '', color: MEMBER_COLORS[S.members.length % MEMBER_COLORS.length] };
  openModal(`${modalHead(id ? 'Editar pessoa' : 'Adicionar pessoa')}<div class="modal-b"><div class="form" id="mform">
    <div class="full"><label for="m-n">Nome</label><input id="m-n" type="text" name="name" value="${esc(m.name)}" maxlength="80"></div>
    <div><label for="m-e">E-mail</label><input id="m-e" type="email" name="email" value="${esc(m.email)}"></div>
    <div><label for="m-r">Cargo</label><input id="m-r" type="text" name="role" value="${esc(m.role)}"></div>
    <div><label for="m-c">Cor</label><input id="m-c" type="color" name="color" value="${esc(m.color)}"></div></div></div>
    <div class="modal-f">${id ? `<button class="btn danger" data-act="del-member" data-id="${id}">${ico('trash')}Excluir</button>` : ''}<span class="sp"></span>
      <button class="btn" data-act="close">Cancelar</button><button class="btn primary" data-act="save-member" data-id="${id || ''}">Salvar</button></div>`, true);
}

// ---- Automações
const TRIGGER_LABELS = { task_created: 'Uma tarefa for criada', status_changed: 'O status mudar', priority_changed: 'A prioridade mudar', assignee_changed: 'O responsável mudar', overdue: 'Uma tarefa ficar atrasada' };
const ACTION_LABELS = { set_status: 'Mover para a coluna', set_priority: 'Definir a prioridade', assign_to: 'Atribuir a', set_progress: 'Definir o progresso', add_comment: 'Comentar na tarefa', notify_slack: 'Avisar no Slack' };

function autoText(a, html) {
  const w = x => (html ? `<b>${esc(x)}</b>` : x);
  let t = '';
  switch (a.trigger_type) {
    case 'task_created': t = 'uma tarefa for criada'; break;
    case 'status_changed': t = a.trigger_value && a.trigger_value !== '*' ? `o status mudar para ${w(a.trigger_value)}` : 'o status mudar'; break;
    case 'priority_changed': t = a.trigger_value && a.trigger_value !== '*' ? `a prioridade mudar para ${w(a.trigger_value)}` : 'a prioridade mudar'; break;
    case 'assignee_changed': t = 'o responsável mudar'; break;
    case 'overdue': t = 'uma tarefa ficar atrasada'; break;
  }
  let r = '';
  switch (a.action_type) {
    case 'set_status': r = `mover para ${w(a.action_value)}`; break;
    case 'set_priority': r = `definir prioridade ${w(a.action_value)}`; break;
    case 'assign_to': r = `atribuir a ${w((member(+a.action_value) || {}).name || '(pessoa removida)')}`; break;
    case 'set_progress': r = `definir progresso em ${w(a.action_value + '%')}`; break;
    case 'add_comment': r = `comentar ${w('“' + a.action_value + '”')}`; break;
    case 'notify_slack': r = 'avisar no Slack'; break;
  }
  return `Quando ${t}, ${r}`;
}

function autoValueFields() {
  const b = board();
  const tt = $('#a-trig').value, at = $('#a-act').value;
  const tv = $('#a-tv'), av = $('#a-av');
  if (tt === 'status_changed') tv.innerHTML = `<label for="a-tvv">Para o status</label><select id="a-tvv" name="trigger_value"><option value="">Qualquer</option>${b.statuses.map(s => `<option>${esc(s)}</option>`).join('')}</select>`;
  else if (tt === 'priority_changed') tv.innerHTML = `<label for="a-tvv">Para a prioridade</label><select id="a-tvv" name="trigger_value"><option value="">Qualquer</option>${PRIOS.map(s => `<option>${s}</option>`).join('')}</select>`;
  else tv.innerHTML = '';
  const L = t => `<label for="a-avv">${t}</label>`;
  if (at === 'set_status') av.innerHTML = L('Coluna') + `<select id="a-avv" name="action_value">${b.statuses.map(s => `<option>${esc(s)}</option>`).join('')}</select>`;
  else if (at === 'set_priority') av.innerHTML = L('Prioridade') + `<select id="a-avv" name="action_value">${PRIOS.map(s => `<option>${s}</option>`).join('')}</select>`;
  else if (at === 'assign_to') av.innerHTML = L('Pessoa') + `<select id="a-avv" name="action_value">${S.members.map(m => `<option value="${m.id}">${esc(m.name)}</option>`).join('')}</select>`;
  else if (at === 'set_progress') av.innerHTML = L('Progresso (%)') + '<input id="a-avv" type="number" name="action_value" min="0" max="100" value="100">';
  else if (at === 'add_comment') av.innerHTML = L('Comentário') + '<input id="a-avv" type="text" name="action_value" placeholder="Ex.: Tarefa concluída, obrigado!">';
  else av.innerHTML = L('Mensagem') + '<input id="a-avv" type="text" name="action_value" value="✅ {responsavel} concluiu &quot;{titulo}&quot; ({quadro})"><p class="hint">Variáveis: {titulo} {status} {responsavel} {quadro} {prazo} {prioridade}</p>';
}

function openAutomations() {
  const b = board();
  const list = S.autos.filter(a => a.board_id === b.id);
  openModal(`${modalHead('Automações de ' + esc(b.name))}<div class="modal-b">
    <p class="muted" style="margin-top:0">Regras que trabalham por você sempre que algo acontece nas tarefas deste quadro.</p>
    <div id="auto-list">${list.length ? list.map(a => `<div class="auto"><label class="switch"><input type="checkbox" data-change="auto-toggle" data-id="${a.id}" ${a.enabled ? 'checked' : ''} aria-label="Ativar automação"><span></span></label>
      <div class="tx">${autoText(a, true)}<div class="muted" style="font-size:12px">Executada ${a.runs} ${a.runs === 1 ? 'vez' : 'vezes'}</div></div>
      <button class="icon-btn" data-act="del-auto" data-id="${a.id}" aria-label="Excluir automação">${ico('trash')}</button></div>`).join('') : '<p class="muted">Nenhuma automação neste quadro ainda.</p>'}</div>
    <h3 style="font-size:16px;margin:18px 0 10px">Nova automação</h3>
    <div class="form" id="aform">
      <div><label for="a-trig">Quando</label><select id="a-trig" name="trigger_type" data-change="auto-form">${Object.entries(TRIGGER_LABELS).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select></div>
      <div id="a-tv"></div>
      <div><label for="a-act">Então</label><select id="a-act" name="action_type" data-change="auto-form">${Object.entries(ACTION_LABELS).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select></div>
      <div id="a-av"></div></div></div>
    <div class="modal-f"><button class="btn" data-act="close">Fechar</button><button class="btn primary" data-act="save-auto">Adicionar automação</button></div>`);
  autoValueFields();
}

// ---------------------------------------------------------------- Ações (cliques)
function copyText(txt) {
  const done = () => toast('Copiado');
  if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(txt).then(done, () => toast('Não foi possível copiar', true));
  else {
    const ta = document.createElement('textarea');
    ta.value = txt; document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); done(); } catch (e) { toast('Não foi possível copiar', true); }
    ta.remove();
  }
}
const saveSettings = async patch => { S.settings = await api('PUT', '/api/settings', patch); };

const ACT = {
  menu() { document.body.classList.toggle('menu'); },
  nav(a) { S.page = a.dataset.page; document.body.classList.remove('menu'); render(); },
  'open-board'(a) { S.page = 'board'; S.boardId = +a.dataset.id; S.f = { q: '', who: '', prio: '' }; document.body.classList.remove('menu'); render(); },
  view(a) { S.view = a.dataset.v; render(); },
  'clear-filters'() { S.f = { q: '', who: '', prio: '' }; render(); },
  sort(a) { const k = a.dataset.k; S.sort = { k, d: S.sort.k === k ? -S.sort.d : 1 }; renderView(); },
  cal(a) { const d = +a.dataset.d; S.cal = d === 0 ? new Date(new Date().getFullYear(), new Date().getMonth(), 1) : new Date(S.cal.getFullYear(), S.cal.getMonth() + d, 1); renderView(); },
  zoom(a) { S.gz = Math.max(10, Math.min(60, S.gz + +a.dataset.d)); renderView(); },
  close() { closeModal(); },
  overlay(a, e) { if (e.target === a) closeModal(); },
  copy(a) { copyText(a.dataset.text); },
  'new-task'(a) { openTask(null, { status: a.dataset.status, due: a.dataset.due }); },
  'open-task'(a) { openTask(+a.dataset.id); },
  async 'save-task'(a) {
    const d = formData($('#tform'));
    if (!d.title.trim()) { toast('Informe o título da tarefa', true); return; }
    if (a.dataset.id) await api('PUT', '/api/tasks/' + a.dataset.id, d);
    else await api('POST', '/api/tasks', { ...d, board_id: S.boardId });
    closeModal(); await refresh(); toast('Tarefa salva');
  },
  async 'del-task'(a) {
    if (!confirm('Excluir esta tarefa? Esta ação não pode ser desfeita.')) return;
    await api('DELETE', '/api/tasks/' + a.dataset.id); closeModal(); await refresh(); toast('Tarefa excluída');
  },
  async 'add-comment'(a) {
    const inp = $('#cmt-in'); const text = inp.value.trim();
    if (!text) return;
    await api('POST', `/api/tasks/${a.dataset.id}/comments`, { text });
    inp.value = ''; await loadComments(a.dataset.id); S.tasks = await api('GET', '/api/tasks'); renderSide();
  },
  'new-board'() { openBoard(null); },
  'edit-board'() { openBoard(S.boardId); },
  async 'save-board'(a) {
    const d = formData($('#bform')); const id = a.dataset.id;
    const statuses = d.statuses.split('\n').map(s => s.trim()).filter(Boolean);
    if (!d.name.trim()) { toast('Dê um nome ao quadro', true); return; }
    if (id) {
      const old = boardOf(+id).statuses, renames = {};
      if (old.length === statuses.length) old.forEach((o, i) => { if (o !== statuses[i]) renames[o] = statuses[i]; });
      await api('PUT', '/api/boards/' + id, { ...d, statuses, renames });
    } else {
      const nb = await api('POST', '/api/boards', { ...d, statuses });
      S.page = 'board'; S.boardId = nb.id;
    }
    closeModal(); await refresh(); toast('Quadro salvo');
  },
  async 'del-board'(a) {
    if (!confirm('Excluir este quadro e todas as suas tarefas? Esta ação não pode ser desfeita.')) return;
    await api('DELETE', '/api/boards/' + a.dataset.id); closeModal(); S.page = 'overview'; await refresh(); toast('Quadro excluído');
  },
  'new-member'() { openMember(null); },
  'edit-member'(a) { openMember(+a.dataset.id); },
  async 'save-member'(a) {
    const d = formData($('#mform'));
    if (!d.name.trim()) { toast('Informe o nome', true); return; }
    if (a.dataset.id) await api('PUT', '/api/members/' + a.dataset.id, d); else await api('POST', '/api/members', d);
    closeModal(); await refresh(); toast('Pessoa salva');
  },
  async 'del-member'(a) {
    if (!confirm('Excluir esta pessoa? As tarefas dela ficam sem responsável.')) return;
    await api('DELETE', '/api/members/' + a.dataset.id); closeModal(); await refresh(); toast('Pessoa excluída');
  },
  automations() { openAutomations(); },
  async 'save-auto'() {
    const d = formData($('#aform'));
    const tmp = { ...d, trigger_value: d.trigger_value || '' };
    await api('POST', '/api/automations', { ...d, board_id: S.boardId, name: autoText(tmp, false).slice(0, 80) });
    S.autos = await api('GET', '/api/automations'); openAutomations(); renderTop(); toast('Automação adicionada');
  },
  async 'del-auto'(a) {
    await api('DELETE', '/api/automations/' + a.dataset.id);
    S.autos = await api('GET', '/api/automations'); openAutomations(); renderTop();
  },
  async 'add-embed'() {
    const url = $('#emb-url').value.trim();
    if (!url) { toast('Cole o link do painel', true); return; }
    await saveSettings({ embeds: [...(S.settings.embeds || []), { name: $('#emb-name').value.trim() || 'Painel', type: $('#emb-type').value, url }] });
    render(); toast('Painel adicionado');
  },
  async 'del-embed'(a) {
    const embeds = (S.settings.embeds || []).filter((_, i) => i !== +a.dataset.i);
    await saveSettings({ embeds }); render();
  },
  async 'save-slack'() { await saveSettings({ slack_webhook: $('#slack-url').value.trim() }); toast('Webhook do Slack salvo'); },
  async 'test-slack'() { await saveSettings({ slack_webhook: $('#slack-url').value.trim() }); await api('POST', '/api/settings/test-slack'); toast('Mensagem de teste enviada ao Slack'); },
  async 'save-hook'() { await saveSettings({ webhook_url: $('#hook-url').value.trim() }); toast('Webhook salvo'); },
  async 'regen-token'() {
    if (!confirm('Gerar um novo token? As URLs configuradas no Power BI e no Grafana deixam de funcionar até serem atualizadas.')) return;
    S.settings = await api('POST', '/api/settings/regenerate-token'); render(); toast('Novo token gerado');
  },
};

document.addEventListener('click', e => {
  const a = e.target.closest('[data-act]');
  if (!a) return;
  const fn = ACT[a.dataset.act];
  if (!fn) return;
  if (a.tagName === 'A') return;
  Promise.resolve(fn(a, e)).catch(err => toast(err.message, true));
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && $('#modal').innerHTML) closeModal();
  if ((e.key === 'Enter' || e.key === ' ') && e.target.classList && e.target.classList.contains('tcard')) { e.preventDefault(); openTask(+e.target.dataset.id); }
  if (e.key === 'Enter' && e.target.id === 'cmt-in') { const btn = $('[data-act="add-comment"]'); if (btn) btn.click(); }
});
document.addEventListener('input', e => {
  const t = e.target;
  if (t.dataset && t.dataset.input === 'q') { S.f.q = t.value; renderView(); }
  if (t.name === 'progress') { const o = $('#f-pv'); if (o) o.textContent = t.value + '%'; }
});
document.addEventListener('change', async e => {
  const t = e.target, k = t.dataset && t.dataset.change;
  if (!k) return;
  try {
    if (k === 'who' || k === 'prio') { S.f[k] = t.value; renderContent(); }
    else if (k === 'field') {
      await api('PUT', '/api/tasks/' + t.dataset.id, { [t.dataset.f]: t.value });
      await refresh();
    } else if (k === 'auto-form') autoValueFields();
    else if (k === 'auto-toggle') {
      await api('PUT', '/api/automations/' + t.dataset.id, { enabled: t.checked });
      S.autos = await api('GET', '/api/automations'); renderTop();
    }
  } catch (err) { toast(err.message, true); if (k === 'field') refresh(); }
});

// ---------------------------------------------------------------- início
(async function init() {
  try {
    await load();
    if (S.boards.length) { S.page = 'board'; S.boardId = S.boards[0].id; }
    render();
  } catch (err) {
    $('#content').innerHTML = `<div class="empty"><b>Não foi possível carregar os dados</b>${esc(err.message)}</div>`;
  }
})();
